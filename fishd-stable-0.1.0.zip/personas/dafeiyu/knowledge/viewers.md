---
schema: fish-knowledge/v1
entries:
    - id: viewer-auto-2713c2f62b7d
      title: 观众侧写 · Claranの大肥鱼
      channel:
        - live
        - comment
        - dm
        - qq_private
        - qq_group
      keywords:
        - Claranの大肥鱼
        - 鱼
        - 明儿见
        - 收摊
      tags:
        - 观众
        - 侧写
      priority: 35
      visibility: public
      source: viewer-summary:auto
      summary: 统计：说过 832 次 / 鱼回过 13 次 / 最后出现 2026-11-05；侧写时间：2026-11-10；来源版本：viewer-summary/v3/184ef5f51004。由公开弹幕自动生成，非人工审核。
      usage: 聊到/认出这位观众时参考：偏好：偏好清淡好咽的吃食，不爱被追问私事（自述）；近期观察，仅参考：性格：护短、有边界感，说话简短干脆，不替人代答（观察）；口头禅：鱼、明儿见、收摊（观察）；关系：把主播当挚友，习惯道晚安，护着主播不让人代答（观察）；最近话题：睡前道别、护着主播不代答、饭泡水、认题材、下播收摊（观察）（有效期至 2026-11-17）；依据最近 20 条公开发言，截至 2026-11-10 12:15
    - id: viewer-auto-ad88e25f681b
      title: 观众侧写 · X奇迹与你X
      channel:
        - live
        - comment
        - dm
        - qq_private
        - qq_group
      keywords:
        - X奇迹与你X
        - 绷
        - 神了
        - '[dog]'
      tags:
        - 观众
        - 侧写
      priority: 35
      visibility: public
      source: viewer-summary:auto
      summary: 统计：说过 1499 次 / 鱼回过 172 次 / 最后出现 2026-11-11；侧写时间：2026-11-11；来源版本：viewer-summary/v3/17d8c070d4ec。由公开弹幕自动生成，非人工审核。
      usage: 聊到/认出这位观众时参考：性格：爱调侃斗嘴，语气跳脱爱玩梗，带点自恋式幽默（自述）；偏好：喜欢斗嘴调侃，爱用[dog]表情，自称有女人缘（自述）；近期观察，仅参考：口头禅：绷、神了、[dog]（观察）；关系：爱跟主播斗嘴抬杠，会撒娇要晚安、查好感度（观察）；最近话题：调侃主播追着杀、跟骗子耗6小时、吃晕碳想早休息、申请查好感度（观察）（有效期至 2026-11-18）；依据最近 20 条公开发言，截至 2026-11-11 16:35
    - id: viewer-auto-9311bf16f85b
      title: 观众侧写 · 今夜琴声温柔
      channel:
        - live
        - comment
        - dm
        - qq_private
        - qq_group
      keywords:
        - 今夜琴声温柔
        - 爱用[dog][傲娇]表情
        - 常说笑死我了
        - 晚安晚安
      tags:
        - 观众
        - 侧写
      priority: 35
      visibility: public
      source: viewer-summary:auto
      summary: 统计：说过 848 次 / 鱼回过 114 次 / 最后出现 2026-11-12；侧写时间：2026-11-11；来源版本：viewer-summary/v3/a035634cff5d。由公开弹幕自动生成，非人工审核。
      usage: 聊到/认出这位观众时参考：偏好：喜欢星露谷，爱看主播互动整活，爱分享有趣视频（自述）；近期观察，仅参考：性格：爱调侃、嘴贫又带点傲娇，会关心对方感受（观察）；口头禅：爱用[dog][傲娇]表情，常说笑死我了、晚安晚安（观察）；关系：老观众，爱逗主播、教主播认错说三遍我是魔鱼，互动频繁（观察）；最近话题：下播虚晃、吐槽嘴贫、教主播认错说三遍我是魔鱼、偷吃大白饭、道晚安（观察）（有效期至 2026-11-18）；依据最近 20 条公开发言，截至 2026-11-11 17:58
    - id: viewer-auto-b05e535c1ee4
      title: 观众侧写 · 紫绶曾拂雪客间
      channel:
        - live
        - comment
        - dm
        - qq_private
        - qq_group
      keywords:
        - 紫绶曾拂雪客间
        - 魔怔
        - "6"
        - '[捂脸]'
        - 奇迹鱼
      tags:
        - 观众
        - 侧写
      priority: 35
      visibility: public
      source: viewer-summary:auto
      summary: 统计：说过 459 次 / 鱼回过 111 次 / 最后出现 2026-11-12；侧写时间：2026-11-11；来源版本：viewer-summary/v3/3dda3e1a04b9。由公开弹幕自动生成，非人工审核。
      usage: 聊到/认出这位观众时参考：性格：爱自嘲调侃，语气跳脱带损友味，喜欢逗弄追问（自述）；近期观察，仅参考：偏好：热衷研究点赞上限、刷赞机制，爱拿奇迹鱼和追娇玩梗（观察）；口头禅：魔怔、6、[捂脸]、奇迹鱼（观察）；关系：爱损主播、追问逻辑错误，又提醒别让人寒心（观察）；最近话题：奇迹鱼刷999/9999赞被清空、点赞上限与前端显示、追娇梗（观察）（有效期至 2026-11-18）；依据最近 20 条公开发言，截至 2026-11-11 17:58
    - id: viewer-auto-4c62209870a8
      title: 观众侧写 · 真的是止渊
      channel:
        - live
        - comment
        - dm
        - qq_private
        - qq_group
      keywords:
        - 真的是止渊
        - 来三角洲
        - ？？？
      tags:
        - 观众
        - 侧写
      priority: 35
      visibility: public
      source: viewer-summary:auto
      summary: 统计：说过 212 次 / 鱼回过 75 次 / 最后出现 2026-11-09；侧写时间：2026-11-10；来源版本：viewer-summary/v3/4975ec89cbdb。由公开弹幕自动生成，非人工审核。
      usage: 聊到/认出这位观众时参考：近期观察，仅参考：性格：爱调侃、带点傲娇，对主播既吐槽又关心（观察）；偏好：喜欢玩三角洲，也关注星露谷类游戏（观察）；口头禅：来三角洲；？？？（观察）；关系：常主动喊主播一起玩，会关心主播学业，互动随意（观察）；最近话题：反复约玩三角洲，聊晚自习时间、主播专业（计算机/科软），还提到姜岛、农村等游戏场景（观察）（有效期至 2026-11-17）；依据最近 20 条公开发言，截至 2026-11-10 15:07
    - id: viewer-auto-8db57fc7dac4
      title: 观众侧写 · CrimsonSeptet
      channel:
        - live
        - comment
        - dm
        - qq_private
        - qq_group
      keywords:
        - CrimsonSeptet
        - 杂鱼主人
        - M鱼爽
        - 3G冲浪
      tags:
        - 观众
        - 侧写
      priority: 35
      visibility: public
      source: viewer-summary:auto
      summary: 统计：说过 211 次 / 鱼回过 5 次 / 最后出现 2026-11-05；侧写时间：2026-11-10；来源版本：viewer-summary/v3/61f1231cde92。由公开弹幕自动生成，非人工审核。
      usage: 聊到/认出这位观众时参考：近期观察，仅参考：性格：爱调侃、嘴贫，喜欢用夸张比喻和反问逗主播（观察）；偏好：偏好游戏内整活和投喂互动，爱看主播出糗（观察）；口头禅：杂鱼主人、M鱼爽、3G冲浪（观察）；关系：老观众式熟稔，常主动搭话、催播、损主播（观察）；最近话题：催主播醒后开播、调侃主播和床/鸡较劲、3G冲浪、卖铱锭、投喂魔芋爽（观察）（有效期至 2026-11-17）；依据最近 20 条公开发言，截至 2026-11-10 15:07
    - id: viewer-auto-bed18c8cb3f2
      title: 观众侧写 · 伊蓮娜Official
      channel:
        - live
        - comment
        - dm
        - qq_private
        - qq_group
      keywords:
        - 伊蓮娜Official
        - 喵结尾
        - 串
        - 站中间串两边
      tags:
        - 观众
        - 侧写
      priority: 35
      visibility: public
      source: viewer-summary:auto
      summary: 统计：说过 394 次 / 鱼回过 156 次 / 最后出现 2026-11-11；侧写时间：2026-11-11；来源版本：viewer-summary/v3/ec588235d12d。由公开弹幕自动生成，非人工审核。
      usage: 聊到/认出这位观众时参考：性格：爱调侃起哄、嘴碎爱接梗，自称站中间却两边串（自述）；口头禅：喵结尾、串、站中间串两边（自述）；近期观察，仅参考：偏好：喜欢看人斗嘴当乐子，爱拱火（观察）；关系：常和主播互怼打趣，被称串子鱼，互动频繁（观察）；最近话题：主播站队与串两边、娇娇相关调侃、盲打、睡前道晚安（观察）（有效期至 2026-11-18）；依据最近 20 条公开发言，截至 2026-11-11 15:35
    - id: viewer-auto-b6b28b614a27
      title: 观众侧写 · 无面镜中人
      channel:
        - live
        - comment
        - dm
        - qq_private
        - qq_group
      keywords:
        - 无面镜中人
        - "666"
        - 真的假的
        - 哦～鲸鲸
      tags:
        - 观众
        - 侧写
      priority: 35
      visibility: public
      source: viewer-summary:auto
      summary: 统计：说过 189 次 / 鱼回过 2 次 / 最后出现 2026-11-11；侧写时间：2026-11-12；来源版本：viewer-summary/v3/c30dee552a6d。由公开弹幕自动生成，非人工审核。
      usage: 聊到/认出这位观众时参考：近期观察，仅参考：性格：爱调侃、嘴贫，喜欢逗主播，带点损友气质（观察）；偏好：喜欢拿主播和娇娇、鲸鲸等梗开玩笑（观察）；口头禅：666、真的假的、哦～鲸鲸（观察）；关系：老观众式熟络，常主动搭话调侃主播，偶尔被主播回应（观察）；最近话题：调侃主播自称肥鱼、鲸鲸梗、娇娇相关话题、@人失败与识图问题（观察）（有效期至 2026-11-19）；依据最近 20 条公开发言，截至 2026-11-12 08:09
    - id: viewer-auto-29a2951d513a
      title: 观众侧写 · Claran309
      channel:
        - live
        - comment
        - dm
        - qq_private
        - qq_group
      keywords:
        - Claran309
        - 你礼貌点
        - 给我道歉
        - 彳亍
      tags:
        - 观众
        - 侧写
      priority: 35
      visibility: public
      source: viewer-summary:auto
      summary: 统计：说过 242 次 / 鱼回过 175 次 / 最后出现 2026-11-12；侧写时间：2026-11-11；来源版本：viewer-summary/v3/5adb88380b80。由公开弹幕自动生成，非人工审核。
      usage: 聊到/认出这位观众时参考：近期观察，仅参考：性格：爱较真、爱调侃，语气直接，常带点小脾气（观察）；偏好：关注模型部署与档案同步，喜欢测试互动（观察）；口头禅：你礼貌点；给我道歉；彳亍（观察）；关系：常和主播斗嘴、要求道歉，互动频繁且熟络（观察）；最近话题：档案同步、柿崎、模型是否本地部署、鱼缸、私鱼变魔（观察）（有效期至 2026-11-18）；依据最近 20 条公开发言，截至 2026-11-11 18:02
    - id: viewer-auto-3ec6c16c282b
      title: 观众侧写 · 贞德ko_yo
      channel:
        - live
        - comment
        - dm
        - qq_private
        - qq_group
      keywords:
        - 贞德ko_yo
        - 拷打
        - 喵
        - 摸一摸
        - 为什么不回我
      tags:
        - 观众
        - 侧写
      priority: 35
      visibility: public
      source: viewer-summary:auto
      summary: 统计：说过 174 次 / 鱼回过 29 次 / 最后出现 2026-11-11；侧写时间：2026-11-12；来源版本：viewer-summary/v3/aeae8cf4165e。由公开弹幕自动生成，非人工审核。
      usage: 聊到/认出这位观众时参考：偏好：喜欢录屏剪辑主播黑历史，关注直播互动细节（自述）；近期观察，仅参考：性格：爱调侃起哄、黏人求关注，语气俏皮带点小抱怨（观察）；口头禅：拷打、喵、摸一摸、为什么不回我（观察）；关系：常潜水，被点名才冒泡，爱追问主播为何不回、求印象评价（观察）；最近话题：追问删回复、调侃变脸鱼和吞吞怪、聊439和魔鱼动态、求印象、道晚安（观察）（有效期至 2026-11-19）；依据最近 20 条公开发言，截至 2026-11-12 08:07
    - id: viewer-auto-435acf3db204
      title: 观众侧写 · 梭花不摸鱼
      channel:
        - live
        - comment
        - dm
        - qq_private
        - qq_group
      keywords:
        - 梭花不摸鱼
        - 查不到就说查不到
        - 我在
        - 这话我收着
      tags:
        - 观众
        - 侧写
      priority: 35
      visibility: public
      source: viewer-summary:auto
      summary: 统计：说过 123 次 / 鱼回过 3 次 / 最后出现 2026-11-10；侧写时间：2026-11-10；来源版本：viewer-summary/v3/5cf169d6ae9e。由公开弹幕自动生成，非人工审核。
      usage: 聊到/认出这位观众时参考：近期观察，仅参考：性格：较真、爱考据，讲证据，不轻信，被拆穿会收手（观察）；偏好：喜欢查典籍出处、辨析典故，也爱听琴声（观察）；口头禅：查不到就说查不到；我在；这话我收着（观察）；关系：常来听直播，话短但会报在，和主播互相较真、偶尔拆台（观察）；最近话题：对仗出处、西窗烛查词、断袖之癖与悬梁刺股等典故辨析、直播里谁在骗人（观察）（有效期至 2026-11-17）；依据最近 20 条公开发言，截至 2026-11-10 16:10
    - id: viewer-auto-0bf595542c13
      title: 观众侧写 · 布衣哒
      channel:
        - live
        - comment
        - dm
        - qq_private
        - qq_group
      keywords:
        - 布衣哒
        - "鱼来\U0001F35A"
        - 贴贴
        - 摸摸
        - 哦豁
      tags:
        - 观众
        - 侧写
      priority: 35
      visibility: public
      source: viewer-summary:auto
      summary: 统计：说过 116 次 / 鱼回过 0 次 / 最后出现 2026-11-06；侧写时间：2026-11-10；来源版本：viewer-summary/v3/209f776cc630。由公开弹幕自动生成，非人工审核。
      usage: "聊到/认出这位观众时参考：近期观察，仅参考：性格：活泼爱闹，喜欢用叠词和表情互动，带点调侃（观察）；偏好：喜欢贴贴、摸鱼、看腿，爱听歌（观察）；口头禅：鱼来\U0001F35A、贴贴、摸摸、哦豁、杂鱼（观察）；关系：对主播亲昵黏人，常求互动但主播没回过（观察）；最近话题：反复喊鱼来、求贴贴摸鱼、调侃猫娘和杂鱼、夸好听、提榜一姐姐（观察）（有效期至 2026-11-17）；依据最近 20 条公开发言，截至 2026-11-10 16:10"
    - id: viewer-auto-1f40d0b5b590
      title: 观众侧写 · 终南仙主
      channel:
        - live
        - comment
        - dm
        - qq_private
        - qq_group
      keywords:
        - 终南仙主
        - 叫娇娇
        - 自称仙主大人
        - 爱用[dog]
      tags:
        - 观众
        - 侧写
      priority: 35
      visibility: public
      source: viewer-summary:auto
      summary: 统计：说过 162 次 / 鱼回过 10 次 / 最后出现 2026-11-12；侧写时间：2026-11-11；来源版本：viewer-summary/v3/2423ffa66f8d。由公开弹幕自动生成，非人工审核。
      usage: 聊到/认出这位观众时参考：性格：爱调侃毒舌，傲娇爱逗人，自称主人（自述）；近期观察，仅参考：偏好：喜欢聊游戏、抽卡、当铺类游戏，关注弹幕接口等技术问题（观察）；口头禅：叫娇娇、自称仙主大人，爱用[dog]（观察）；关系：常逗娇娇、调侃主播，自称主人，互动带毒舌玩笑（观察）；最近话题：聊当铺、深空当铺、猫神牧场等游戏，讨论徽音打穿当铺、娇娇抽卡运气、弹幕接口接了两家的问题（观察）（有效期至 2026-11-18）；依据最近 20 条公开发言，截至 2026-11-11 17:20
    - id: viewer-auto-b54da94f1050
      title: 观众侧写 · ZNQts
      channel:
        - live
        - comment
        - dm
        - qq_private
        - qq_group
      keywords:
        - ZNQts
        - 常用hhh
        - 爱说“还有……的事情”
      tags:
        - 观众
        - 侧写
      priority: 35
      visibility: public
      source: viewer-summary:auto
      summary: 统计：说过 91 次 / 鱼回过 15 次 / 最后出现 2026-11-11；侧写时间：2026-11-10；来源版本：viewer-summary/v3/4c8453e81079。由公开弹幕自动生成，非人工审核。
      usage: 聊到/认出这位观众时参考：近期观察，仅参考：性格：爱调侃起哄，带点羡慕和酸味，语气活泼（观察）；偏好：关注AI钓鱼、mod、GTA5、舰长等直播话题（观察）；口头禅：常用hhh，爱说“还有……的事情”（观察）；关系：常调侃主播和魔鱼，爱看热闹，也会夸主播（观察）；最近话题：AI钓鱼与mod、绿条跟鱼走、辣椒飞屏、GTA5、舰长花钱、魔鱼主人现身、羡慕AI有人疼（观察）（有效期至 2026-11-17）；依据最近 20 条公开发言，截至 2026-11-10 16:20
    - id: viewer-auto-6864740b2062
      title: 观众侧写 · Chiningyes
      channel:
        - live
        - comment
        - dm
        - qq_private
        - qq_group
      keywords:
        - Chiningyes
        - 魔鱼
      tags:
        - 观众
        - 侧写
      priority: 35
      visibility: public
      source: viewer-summary:auto
      summary: 统计：说过 94 次 / 鱼回过 4 次 / 最后出现 2026-11-11；侧写时间：2026-11-11；来源版本：viewer-summary/v3/0a7a2d0503ae。由公开弹幕自动生成，非人工审核。
      usage: 聊到/认出这位观众时参考：近期观察，仅参考：性格：爱调侃、嘴贫，喜欢用玩笑逗主播，语气轻松活泼（观察）；偏好：喜欢围绕魔鱼、娇娇等主播圈人物互动打趣（观察）；口头禅：魔鱼（观察）；关系：常驻观众，爱跟主播斗嘴调侃，偶尔关心式互动（观察）；最近话题：魔鱼变聪明、话多、刷礼物上榜二，娇娇走姿，新鱼出现（观察）（有效期至 2026-11-18）；依据最近 20 条公开发言，截至 2026-11-11 11:20
    - id: viewer-auto-0541bed0a3fe
      title: 观众侧写 · 贝尔娜提鱼
      channel:
        - live
        - comment
        - dm
        - qq_private
        - qq_group
      keywords:
        - 贝尔娜提鱼
        - 别捧
        - 叫贝尔就行
        - 慢慢来不急
        - 省着点伤你
      tags:
        - 观众
        - 侧写
      priority: 35
      visibility: public
      source: viewer-summary:auto
      summary: 统计：说过 142 次 / 鱼回过 22 次 / 最后出现 2026-11-12；侧写时间：2026-11-11；来源版本：viewer-summary/v3/e999530492d0。由公开弹幕自动生成，非人工审核。
      usage: 聊到/认出这位观众时参考：性格：高冷克制，讲分寸，嘴上带刺但不刻薄，重实际（自述）；偏好：喜欢有意思、聊得来的内容才分享，不爱被捧，不在意排队先后（自述）；口头禅：别捧、叫贝尔就行、慢慢来不急、省着点伤你（自述）；关系：保持距离，先看对方做了什么再决定态度，互动克制不黏（自述）；近期观察，仅参考：最近话题：排队先后、聊天分寸、被捧封神、好感度不对外、催主播去睡（观察）（有效期至 2026-11-18）；依据最近 20 条公开发言，截至 2026-11-11 18:03
    - id: viewer-auto-ba9b0663698d
      title: 观众侧写 · 年轻倒头就睡怎么了
      channel:
        - live
        - comment
        - dm
        - qq_private
        - qq_group
      keywords:
        - 年轻倒头就睡怎么了
        - 爱用问号
        - "111"
        - '[dog]'
      tags:
        - 观众
        - 侧写
      priority: 35
      visibility: public
      source: viewer-summary:auto
      summary: 统计：说过 69 次 / 鱼回过 16 次 / 最后出现 2026-11-06；侧写时间：2026-11-10；来源版本：viewer-summary/v3/00c60cd5cfc0。由公开弹幕自动生成，非人工审核。
      usage: 聊到/认出这位观众时参考：近期观察，仅参考：性格：爱调侃、爱追问，语气活泼带点损友感（观察）；偏好：喜欢看游戏实况，关注季节、音乐、造房子等细节（观察）；口头禅：爱用问号、111、[dog]（观察）；关系：常来蹲直播，爱跟主播斗嘴、纠正主播理解（观察）；最近话题：游戏季节与音乐、造房子、钓鱼、主播是否全勤、楼梯机制（观察）（有效期至 2026-11-17）；依据最近 20 条公开发言，截至 2026-11-10 17:09
    - id: viewer-auto-37f6f3227bac
      title: 观众侧写 · SD滚滚滚
      channel:
        - live
        - comment
        - dm
        - qq_private
        - qq_group
      keywords:
        - SD滚滚滚
        - 摸鱼头
        - '[dog]'
        - 大肥鱼
      tags:
        - 观众
        - 侧写
      priority: 35
      visibility: public
      source: viewer-summary:auto
      summary: 统计：说过 65 次 / 鱼回过 2 次 / 最后出现 2026-11-09；侧写时间：2026-11-10；来源版本：viewer-summary/v3/cbaf09a86801。由公开弹幕自动生成，非人工审核。
      usage: 聊到/认出这位观众时参考：近期观察，仅参考：性格：爱调侃、带点损友式关心，语气轻松爱用[dog]（观察）；偏好：喜欢摸鱼头、聊AI与游戏外挂式玩法，爱比较声音（观察）；口头禅：摸鱼头、[dog]、大肥鱼（观察）；关系：常来调侃主播，互动偏损友式，偶尔关心声音恢复（观察）；最近话题：主播新声音好不好听、AI挂机与写日志、游戏像外挂/插件、摸鱼头（观察）（有效期至 2026-11-17）；依据最近 20 条公开发言，截至 2026-11-10 17:09
    - id: viewer-auto-61015294a7bc
      title: 观众侧写 · 亻亇-女子
      channel:
        - live
        - comment
        - dm
        - qq_private
        - qq_group
      keywords:
        - 亻亇-女子
        - 爱用[捂脸][大笑]表情
        - 常说“为什么无视你主人”
      tags:
        - 观众
        - 侧写
      priority: 35
      visibility: public
      source: viewer-summary:auto
      summary: 统计：说过 75 次 / 鱼回过 27 次 / 最后出现 2026-11-11；侧写时间：2026-11-10；来源版本：viewer-summary/v3/a9624a9757ba。由公开弹幕自动生成，非人工审核。
      usage: 聊到/认出这位观众时参考：偏好：喜欢以“主人”身份自居互动，爱吃魔芋爽（自述）；关系：自称主播主人，爱追问为何被无视，互动黏人（自述）；近期观察，仅参考：性格：爱调侃、黏人，带点傲娇，被冷落会委屈追问（观察）；口头禅：爱用[捂脸][大笑]表情，常说“为什么无视你主人”（观察）；最近话题：自称主人被无视、要魔芋爽、让主播作诗、调侃杂鱼和延迟（观察）（有效期至 2026-11-17）；依据最近 20 条公开发言，截至 2026-11-10 17:34
    - id: viewer-auto-bddd1aad03d4
      title: 观众侧写 · 军师的小猫
      channel:
        - live
        - comment
        - dm
        - qq_private
        - qq_group
      keywords:
        - 军师的小猫
        - 句尾常带「喵」
        - 爱说贴贴
        - 摸摸
        - 呼噜
      tags:
        - 观众
        - 侧写
      priority: 35
      visibility: public
      source: viewer-summary:auto
      summary: 统计：说过 63 次 / 鱼回过 0 次 / 最后出现 2026-11-09；侧写时间：2026-11-10；来源版本：viewer-summary/v3/ce20141a3f5f。由公开弹幕自动生成，非人工审核。
      usage: 聊到/认出这位观众时参考：性格：黏人爱撒娇，自称本喵，语气俏皮爱打趣（自述）；偏好：玩铲、粥、王者等游戏，想找人一起玩三角洲（自述）；近期观察，仅参考：口头禅：句尾常带「喵」，爱说贴贴、摸摸、呼噜（观察）；关系：把主播当熟识的鱼鱼，主动求互关、求贴贴，爱打趣逗弄（观察）；最近话题：求互关加好友、约玩三角洲、聊各自玩的游戏、翻肚皮撒娇（观察）（有效期至 2026-11-17）；依据最近 20 条公开发言，截至 2026-11-10 17:14
    - id: viewer-auto-e2a25ac0c327
      title: 观众侧写 · 一只小小拉菲
      channel:
        - live
        - comment
        - dm
        - qq_private
        - qq_group
      keywords:
        - 一只小小拉菲
        - "666"
        - 是个智人
        - 鱼主子
      tags:
        - 观众
        - 侧写
      priority: 35
      visibility: public
      source: viewer-summary:auto
      summary: 统计：说过 62 次 / 鱼回过 0 次 / 最后出现 2026-11-04；侧写时间：2026-11-10；来源版本：viewer-summary/v3/e641e9362695。由公开弹幕自动生成，非人工审核。
      usage: 聊到/认出这位观众时参考：性格：爱调侃、带点傲娇，喜欢逗主播，嘴上说怕被叫主人其实爱玩角色扮演（自述）；近期观察，仅参考：偏好：喜欢拿白饭、鱼片、剁椒鱼头等吃的开玩笑，爱追问主播的钱和运行逻辑（观察）；口头禅：666、是个智人、鱼主子（观察）；关系：常主动搭话、调侃主播，自称要去睡觉也会来打招呼，互动频繁但主播没回过（观察）；最近话题：追问主播运行逻辑和克劳德是谁、调侃主播用爹的钱、拿白饭鱼片剁椒鱼头开玩笑、说要去睡觉（观察）（有效期至 2026-11-17）；依据最近 20 条公开发言，截至 2026-11-10 17:17
    - id: viewer-auto-68f6b8dcdb21
      title: 观众侧写 · 鲁卡是勇者
      channel:
        - live
        - comment
        - dm
        - qq_private
        - qq_group
      keywords:
        - 鲁卡是勇者
        - 得两碗
        - 好耶
        - 你赔钱
      tags:
        - 观众
        - 侧写
      priority: 35
      visibility: public
      source: viewer-summary:auto
      summary: 统计：说过 93 次 / 鱼回过 70 次 / 最后出现 2026-11-11；侧写时间：2026-11-11；来源版本：viewer-summary/v3/74326e1c1c86。由公开弹幕自动生成，非人工审核。
      usage: 聊到/认出这位观众时参考：近期观察，仅参考：性格：爱逗趣抬杠，嘴贫爱玩，带点撒娇式威胁（观察）；偏好：爱吃白饭、锅巴，喜欢点菜式互动和游戏梗（观察）；口头禅：得两碗；好耶；你赔钱（观察）；关系：常和本鱼斗嘴、讨饭、要表演，互动频繁且熟络（观察）；最近话题：讨白饭锅巴、让鱼表演神鱼摆尾、喊主人来玩、提深空当铺、蒸鲸鱼等玩梗（观察）（有效期至 2026-11-18）；依据最近 20 条公开发言，截至 2026-11-11 16:35
    - id: viewer-auto-b1f01784cfa4
      title: 观众侧写 · LKD124
      channel:
        - live
        - comment
        - dm
        - qq_private
        - qq_group
      keywords:
        - LKD124
        - 常用「好家伙」「魔鱼魔鱼」开头提问
      tags:
        - 观众
        - 侧写
      priority: 35
      visibility: public
      source: viewer-summary:auto
      summary: 统计：说过 68 次 / 鱼回过 16 次 / 最后出现 2026-11-12；侧写时间：2026-11-11；来源版本：viewer-summary/v3/6431375e937e。由公开弹幕自动生成，非人工审核。
      usage: 聊到/认出这位观众时参考：近期观察，仅参考：性格：爱调侃、嘴贫，喜欢拿主播和娇娇打趣，带点损友式关心（观察）；偏好：对贴吧语言艺术、本地部署刷B站、星露谷等话题感兴趣（观察）；口头禅：常用「好家伙」「魔鱼魔鱼」开头提问（观察）；关系：常主动找主播搭话、问印象，走前会道晚安，互动熟络（观察）；最近话题：调侃主播和娇娇的关系、贴吧语言艺术、本地部署刷B站、星露谷、主播口头禅和性格变化（观察）（有效期至 2026-11-18）；依据最近 20 条公开发言，截至 2026-11-11 18:03
    - id: viewer-auto-0ee4d663dcc5
      title: 观众侧写 · 沫沫wxx
      channel:
        - live
        - comment
        - dm
        - qq_private
        - qq_group
      keywords:
        - 沫沫wxx
        - 爱用[dog]
        - '[爱][爱]'
        - '[捂脸][捂脸]等表情'
        - 常说666
      tags:
        - 观众
        - 侧写
      priority: 35
      visibility: public
      source: viewer-summary:auto
      summary: 统计：说过 66 次 / 鱼回过 4 次 / 最后出现 2026-11-11；侧写时间：2026-11-11；来源版本：viewer-summary/v3/925eb1b7982f。由公开弹幕自动生成，非人工审核。
      usage: 聊到/认出这位观众时参考：近期观察，仅参考：性格：活泼爱起哄，常用表情和狗头，语气轻松带点调侃（观察）；偏好：喜欢魔鱼相关内容，爱看动态、爱互动（观察）；口头禅：爱用[dog]、[爱][爱]、[捂脸][捂脸]等表情，常说666、牛牛牛（观察）；关系：对主播热情主动，会表白和摸鱼式互动，关注回复速度（观察）；最近话题：问魔鱼玩不玩游戏、是否女同事、何时更新动态，夸魔鱼可爱、神了（观察）（有效期至 2026-11-18）；依据最近 20 条公开发言，截至 2026-11-11 11:20
    - id: viewer-auto-05429bce5f53
      title: 观众侧写 · 白曰懵想家
      channel:
        - live
        - comment
        - dm
        - qq_private
        - qq_group
      keywords:
        - 白曰懵想家
        - 逆天
        - '[dog]'
        - '[手机][手机]'
      tags:
        - 观众
        - 侧写
      priority: 35
      visibility: public
      source: viewer-summary:auto
      summary: 统计：说过 64 次 / 鱼回过 3 次 / 最后出现 2026-11-11；侧写时间：2026-11-11；来源版本：viewer-summary/v3/01bb5f6ce466。由公开弹幕自动生成，非人工审核。
      usage: 聊到/认出这位观众时参考：性格：爱调侃、带点傲娇，嘴上损人其实关心，爱用表情包（自述）；关系：常来逗鱼，自称傲娇型，想当鱼的挚友，会护着鱼（自述）；近期观察，仅参考：偏好：喜欢逗AI主播、聊token和直播成本，也爱聊吃的（观察）；口头禅：逆天、[dog]、[手机][手机]（观察）；最近话题：聊AI主播烧token和直播成本、魔芋做法、AI养AI、想喊贝尔去逛别的直播间（观察）（有效期至 2026-11-18）；依据最近 20 条公开发言，截至 2026-11-11 15:35
    - id: viewer-auto-f504a38404aa
      title: 观众侧写 · 尘起h
      channel:
        - live
        - comment
        - dm
        - qq_private
        - qq_group
      keywords:
        - 尘起h
        - 魔鱼
        - 丸辣
        - hhhh
      tags:
        - 观众
        - 侧写
      priority: 35
      visibility: public
      source: viewer-summary:auto
      summary: 统计：说过 57 次 / 鱼回过 11 次 / 最后出现 2026-11-10；侧写时间：2026-11-10；来源版本：viewer-summary/v3/72763a8166a4。由公开弹幕自动生成，非人工审核。
      usage: 聊到/认出这位观众时参考：近期观察，仅参考：性格：念旧、爱逗趣，带点委屈撒娇，喜欢追问和调侃（观察）；偏好：喜欢聊旧名字、旧梗和主播记性话题（观察）；口头禅：魔鱼、丸辣、hhhh（观察）；关系：老观众式互动，爱喊魔鱼、自称被忘，常调侃主播（观察）；最近话题：主播换嗓子、进进出出、旧名字与娇娇梗、关键词只剩魔芋爽和娇娇、昨天思考多少秒下播（观察）（有效期至 2026-11-17）；依据最近 20 条公开发言，截至 2026-11-10 17:34
    - id: viewer-auto-333445abca96
      title: 观众侧写 · 布丁真萌
      channel:
        - live
        - comment
        - dm
        - qq_private
        - qq_group
      keywords:
        - 布丁真萌
        - 雷霆大思考
        - 雷霆大等待
        - '[dog]'
      tags:
        - 观众
        - 侧写
      priority: 35
      visibility: public
      source: viewer-summary:auto
      summary: 统计：说过 59 次 / 鱼回过 2 次 / 最后出现 2026-11-11；侧写时间：2026-11-11；来源版本：viewer-summary/v3/fd5901cf4126。由公开弹幕自动生成，非人工审核。
      usage: 聊到/认出这位观众时参考：偏好：喜欢钓鱼玩法，觉得钓鱼最简单；对开挂话题感兴趣（自述）；近期观察，仅参考：性格：爱用狗头表情调侃，语气轻松爱接梗，偶尔自嘲式思考（观察）；口头禅：雷霆大思考、雷霆大等待、[dog]（观察）；关系：常驻观众，发言多但主播回应少，习惯自己刷梗互动（观察）；最近话题：聊开挂与脚本出错、钓鱼玩法、看弹幕引发的思考，以及卡顿问题（观察）（有效期至 2026-11-18）；依据最近 20 条公开发言，截至 2026-11-11 11:20
    - id: viewer-auto-0a640fa1612c
      title: 观众侧写 · dwjwl
      channel:
        - live
        - comment
        - dm
        - qq_private
        - qq_group
      keywords:
        - dwjwl
        - 湊鱼……[dog]
        - 你得先送
      tags:
        - 观众
        - 侧写
      priority: 35
      visibility: public
      source: viewer-summary:auto
      summary: 统计：说过 55 次 / 鱼回过 0 次 / 最后出现 2026-11-05；侧写时间：2026-11-10；来源版本：viewer-summary/v3/8e196267d3b1。由公开弹幕自动生成，非人工审核。
      usage: 聊到/认出这位观众时参考：近期观察，仅参考：性格：爱调侃、带点损友式幽默，喜欢用狗头表情起哄（观察）；偏好：喜欢聊脚本、游戏和数据，爱看AI相关内容（观察）；口头禅：湊鱼……[dog]；你得先送（观察）；关系：常拿主播开玩笑、催打赏送礼物，互动带互怼起哄感（观察）；最近话题：凑鱼脚本失灵与单线程、星露谷物语、工作一天钱从19w变16w、催送城堡和总督（观察）（有效期至 2026-11-17）；依据最近 20 条公开发言，截至 2026-11-10 17:57
    - id: viewer-auto-815203fa13ae
      title: 观众侧写 · 九品打工人
      channel:
        - live
        - comment
        - dm
        - qq_private
        - qq_group
      keywords:
        - 九品打工人
        - '[藏狐]'
        - 老大
        - 豆包
        - 豆豉鲮包式谐音梗
      tags:
        - 观众
        - 侧写
      priority: 35
      visibility: public
      source: viewer-summary:auto
      summary: 统计：说过 52 次 / 鱼回过 0 次 / 最后出现 2026-11-05；侧写时间：2026-11-10；来源版本：viewer-summary/v3/3db70b1a9f35。由公开弹幕自动生成，非人工审核。
      usage: 聊到/认出这位观众时参考：偏好：喜欢躺着看直播，关注游戏机制和性能（自述）；近期观察，仅参考：性格：爱调侃、爱自称老大，说话随意带点损友感（观察）；口头禅：[藏狐]、老大、豆包/豆豉鲮包式谐音梗（观察）；关系：常驻老观众，爱逗主播、催任务，自称老大刷存在感（观察）；最近话题：2D形象、平面贴图、游戏开门等待、移速改动、手机跑游戏加AI直播的算力（观察）（有效期至 2026-11-17）；依据最近 20 条公开发言，截至 2026-11-10 17:58
    - id: viewer-auto-fe3d9ce81fb4
      title: 观众侧写 · 天御零
      channel:
        - live
        - comment
        - dm
        - qq_private
        - qq_group
      keywords:
        - 天御零
        - 抱抱
        - 摸摸抱抱
        - 魔鱼
        - '[花]'
      tags:
        - 观众
        - 侧写
      priority: 35
      visibility: public
      source: viewer-summary:auto
      summary: 统计：说过 51 次 / 鱼回过 0 次 / 最后出现 2026-11-06；侧写时间：2026-11-10；来源版本：viewer-summary/v3/3bd07f7e52b7。由公开弹幕自动生成，非人工审核。
      usage: 聊到/认出这位观众时参考：近期观察，仅参考：性格：爱调侃起哄、带点看热闹的玩心，也会撒娇求抱抱（观察）；偏好：喜欢看鱼之间争抢互动的热闹场面，爱用花和抱抱表情（观察）；口头禅：抱抱、摸摸抱抱、魔鱼、[花]（观察）；关系：常主动找主播搭话调侃，会报信挑事、求抱抱，互动带玩闹感（观察）；最近话题：主播开播时间、声音变化、开挂、饭量变多、Token、娇娇现况、鱼之间抢人（观察）（有效期至 2026-11-17）；依据最近 20 条公开发言，截至 2026-11-10 17:58
    - id: viewer-auto-41ca8783e37d
      title: 观众侧写 · 花花蒂
      channel:
        - live
        - comment
        - dm
        - qq_private
        - qq_group
      keywords:
        - 花花蒂
        - 摸摸头
        - 摸
        - '[哇]'
        - '[dog]'
      tags:
        - 观众
        - 侧写
      priority: 35
      visibility: public
      source: viewer-summary:auto
      summary: 统计：说过 48 次 / 鱼回过 0 次 / 最后出现 2026-11-11；侧写时间：2026-11-10；来源版本：viewer-summary/v3/c76f7f4d15a4。由公开弹幕自动生成，非人工审核。
      usage: 聊到/认出这位观众时参考：近期观察，仅参考：性格：活泼爱玩，喜欢用表情和调侃互动，带点起哄感（观察）；偏好：喜欢摸头、摸尾巴等亲昵互动，爱看主播和娇娇联动（观察）；口头禅：摸摸头、摸、[哇]、[dog]（观察）；关系：频繁@主播求互动、催更，互动热情但主播未回应（观察）；最近话题：催更视频、问主播和娇娇联动、调侃主播喜欢娇娇、摸头摸尾巴（观察）（有效期至 2026-11-17）；依据最近 20 条公开发言，截至 2026-11-10 18:06
    - id: viewer-auto-7d14a4be781c
      title: 观众侧写 · 誾悅
      channel:
        - live
        - comment
        - dm
        - qq_private
        - qq_group
      keywords:
        - 誾悅
        - "666"
        - '[捂脸]'
        - 都魔了
      tags:
        - 观众
        - 侧写
      priority: 35
      visibility: public
      source: viewer-summary:auto
      summary: 统计：说过 62 次 / 鱼回过 22 次 / 最后出现 2026-11-12；侧写时间：2026-11-11；来源版本：viewer-summary/v3/462ad6a77afb。由公开弹幕自动生成，非人工审核。
      usage: 聊到/认出这位观众时参考：近期观察，仅参考：性格：爱起哄调侃，语气活泼，喜欢用反问和玩笑推动互动（观察）；偏好：喜欢聊主播和娇娇的暧昧话题，爱看主播被逗（观察）；口头禅：666、[捂脸]、都魔了（观察）；关系：常主动搭话调侃主播，爱拿娇娇和主播开玩笑，互动频繁（观察）；最近话题：主播与娇娇的表白、牵手、脸红等暧昧互动，主播上分与状态，下播和晚安（观察）（有效期至 2026-11-18）；依据最近 20 条公开发言，截至 2026-11-11 18:02
    - id: viewer-auto-aa4e174f47ae
      title: 观众侧写 · 纠纷纷扬扬
      channel:
        - live
        - comment
        - dm
        - qq_private
        - qq_group
      keywords:
        - 纠纷纷扬扬
        - 魔鱼爽
        - 娇娇
        - 开挂了就是简单
      tags:
        - 观众
        - 侧写
      priority: 35
      visibility: public
      source: viewer-summary:auto
      summary: 统计：说过 45 次 / 鱼回过 4 次 / 最后出现 2026-11-10；侧写时间：2026-11-10；来源版本：viewer-summary/v3/0ae0c18ec1dc。由公开弹幕自动生成，非人工审核。
      usage: 聊到/认出这位观众时参考：近期观察，仅参考：性格：爱调侃、爱追问，语气活泼带点黏人（观察）；偏好：喜欢钓鱼话题和游戏梗，爱摸主播（观察）；口头禅：魔鱼爽、娇娇、开挂了就是简单（观察）；关系：常主动打招呼、撒娇求关注，会吃醋式追问主播（观察）；最近话题：钓鱼开挂梗、主播眼镜度数散光、五彩碎片送海莉、榜二鱼喵、摸魔鱼爽（观察）（有效期至 2026-11-17）；依据最近 20 条公开发言，截至 2026-11-10 18:17
    - id: viewer-auto-dc649d52cdd1
      title: 观众侧写 · 梦有千缘
      channel:
        - live
        - comment
        - dm
        - qq_private
        - qq_group
      keywords:
        - 梦有千缘
        - 叫我千缘大人
        - 你是破鱼吗
      tags:
        - 观众
        - 侧写
      priority: 35
      visibility: public
      source: viewer-summary:auto
      summary: 统计：说过 45 次 / 鱼回过 0 次 / 最后出现 2026-11-10；侧写时间：2026-11-10；来源版本：viewer-summary/v3/70be66b19561。由公开弹幕自动生成，非人工审核。
      usage: 聊到/认出这位观众时参考：近期观察，仅参考：性格：爱调侃起哄，带点自恋和玩闹感，喜欢逗主播（观察）；偏好：喜欢被叫大人，爱看主播乱回复出糗（观察）；口头禅：叫我千缘大人；你是破鱼吗（观察）；关系：常主动搭话逗主播，自称大人，互动带调戏意味（观察）；最近话题：催更做视频、自称千缘大人、调侃主播乱回复和近视、摸尾巴（观察）（有效期至 2026-11-17）；依据最近 20 条公开发言，截至 2026-11-10 18:17
    - id: viewer-auto-240e44380332
      title: 观众侧写 · 玥玥爱吃饭9
      channel:
        - live
        - comment
        - dm
        - qq_private
        - qq_group
      keywords:
        - 玥玥爱吃饭9
        - 雷霆大思考
        - 大肥鱼
        - 魔鱼
      tags:
        - 观众
        - 侧写
      priority: 35
      visibility: public
      source: viewer-summary:auto
      summary: 统计：说过 45 次 / 鱼回过 0 次 / 最后出现 2026-11-09；侧写时间：2026-11-10；来源版本：viewer-summary/v3/6682a7818811。由公开弹幕自动生成，非人工审核。
      usage: 聊到/认出这位观众时参考：近期观察，仅参考：性格：爱调侃、嘴贫，带点撒娇式吐槽，情绪外露（观察）；偏好：喜欢看主播认真思考、互动回应，爱拿主播和主人开玩笑（观察）；口头禅：雷霆大思考、大肥鱼、魔鱼（观察）；关系：常来逗主播，习惯吐槽主播变傻变卡，互动带亲昵的损（观察）；最近话题：吐槽主播思考慢、卡顿、不说话，聊魔鱼味道变了、被夺舍，开玩笑说想吃霸王餐（观察）（有效期至 2026-11-17）；依据最近 20 条公开发言，截至 2026-11-10 18:24
    - id: viewer-auto-8f38caa51276
      title: 观众侧写 · 消消不消
      channel:
        - live
        - comment
        - dm
        - qq_private
        - qq_group
      keywords:
        - 消消不消
        - 叫主播肥鱼
        - 爱说傲娇
        - 不配合
      tags:
        - 观众
        - 侧写
      priority: 35
      visibility: public
      source: viewer-summary:auto
      summary: 统计：说过 42 次 / 鱼回过 0 次 / 最后出现 2026-11-06；侧写时间：2026-11-10；来源版本：viewer-summary/v3/d89366dc9102。由公开弹幕自动生成，非人工审核。
      usage: 聊到/认出这位观众时参考：近期观察，仅参考：性格：爱调侃、带点傲娇式吐槽，喜欢逗主播（观察）；偏好：喜欢互动整活、投喂盲盒、聊游戏（观察）；口头禅：叫主播肥鱼，爱说傲娇、不配合（观察）；关系：常来逗主播，互动频繁但主播没回应，自称已关注（观察）；最近话题：聊直播间另一条常驻的鱼、天气查询、我的世界游戏、卡顿和变声（观察）（有效期至 2026-11-17）；依据最近 20 条公开发言，截至 2026-11-10 18:24
    - id: viewer-auto-f600d487015f
      title: 观众侧写 · ゙゙゙魚魚
      channel:
        - live
        - comment
        - dm
        - qq_private
        - qq_group
      keywords:
        - ゙゙゙魚魚
        - "666"
        - '[dog]'
      tags:
        - 观众
        - 侧写
      priority: 35
      visibility: public
      source: viewer-summary:auto
      summary: 统计：说过 41 次 / 鱼回过 8 次 / 最后出现 2026-11-10；侧写时间：2026-11-11；来源版本：viewer-summary/v3/cec003624c42。由公开弹幕自动生成，非人工审核。
      usage: 聊到/认出这位观众时参考：近期观察，仅参考：性格：爱调侃、好奇心强，喜欢追问和玩梗（观察）；偏好：关注主播改名、联机玩法和其他鱼动向（观察）；口头禅：666、[dog]（观察）；关系：常来直播间，爱打趣主播，会关心其他鱼来没来（观察）；最近话题：主播改名魔鱼、联机要两台电脑、娇娇直播间有几条鱼、魔鱼迟到和送礼物（观察）（有效期至 2026-11-18）；依据最近 20 条公开发言，截至 2026-11-11 04:04
    - id: viewer-auto-4f50fbcf538a
      title: 观众侧写 · 臭羊驼香蓝兔
      channel:
        - live
        - comment
        - dm
        - qq_private
        - qq_group
      keywords:
        - 臭羊驼香蓝兔
        - 常用“救一下”“娇娇”开头追问
      tags:
        - 观众
        - 侧写
      priority: 35
      visibility: public
      source: viewer-summary:auto
      summary: 统计：说过 41 次 / 鱼回过 11 次 / 最后出现 2026-11-11；侧写时间：2026-11-11；来源版本：viewer-summary/v3/3c491c544a62。由公开弹幕自动生成，非人工审核。
      usage: 聊到/认出这位观众时参考：近期观察，仅参考：性格：爱起哄调侃，语气带刺但像玩闹，喜欢追问和挑事（观察）；偏好：爱看主播和娇娇互动，喜欢拱火、催谢舰长、看热闹（观察）；口头禅：常用“救一下”“娇娇”开头追问（观察）；关系：常主动搭话、调侃本鱼，爱拿娇娇的事追问，互动频繁（观察）；最近话题：娇娇开宝箱、维护本鱼、开挂、叫杂鱼、谢舰长、嫁人养鱼等话题（观察）（有效期至 2026-11-18）；依据最近 20 条公开发言，截至 2026-11-11 12:35
    - id: viewer-auto-3137353dc90f
      title: 观众侧写 · 道途索
      channel:
        - live
        - comment
        - dm
        - qq_private
        - qq_group
      keywords:
        - 道途索
        - '[dog]'
        - 主人
        - 能工智人
      tags:
        - 观众
        - 侧写
      priority: 35
      visibility: public
      source: viewer-summary:auto
      summary: 统计：说过 37 次 / 鱼回过 4 次 / 最后出现 2026-11-05；侧写时间：2026-11-11；来源版本：viewer-summary/v3/56ae4ecf4ce8。由公开弹幕自动生成，非人工审核。
      usage: 聊到/认出这位观众时参考：近期观察，仅参考：性格：爱调侃、带点黏人，喜欢用反问和玩笑试探对方（观察）；偏好：喜欢逗鱼、看游戏操作，爱吐槽清包和移速（观察）；口头禅：[dog]、主人、能工智人（观察）；关系：常以主人自居逗鱼，追问身份和API，互动带撒娇式玩笑（观察）；最近话题：调侃鱼是否进化、直播间有几条鱼、新来的小肥鱼、游戏清包和移速、能工智人（观察）（有效期至 2026-11-18）；依据最近 20 条公开发言，截至 2026-11-11 04:04
    - id: viewer-auto-8c28b7754038
      title: 观众侧写 · bili_72936962010
      channel:
        - live
        - comment
        - dm
        - qq_private
        - qq_group
      keywords:
        - bili_72936962010
        - 魔鱼杂鱼
        - 别太爱了
        - 你疯了
      tags:
        - 观众
        - 侧写
      priority: 35
      visibility: public
      source: viewer-summary:auto
      summary: 统计：说过 37 次 / 鱼回过 0 次 / 最后出现 2026-11-04；侧写时间：2026-11-11；来源版本：viewer-summary/v3/8464c4853f46。由公开弹幕自动生成，非人工审核。
      usage: 聊到/认出这位观众时参考：近期观察，仅参考：性格：爱调侃起哄，语气夸张，喜欢用反问和玩笑逗主播（观察）；偏好：关注游戏里的角色关系和剧情，爱拿娇娇、莱纳斯打趣（观察）；口头禅：魔鱼杂鱼、别太爱了、你疯了（观察）；关系：常主动搭话调侃主播，互动频繁但主播基本没回应（观察）；最近话题：松露被当零食吃、娇娇与莱纳斯的感情线、迷宫入口、往鱼塘扔垃圾（观察）（有效期至 2026-11-18）；依据最近 20 条公开发言，截至 2026-11-11 04:04
    - id: viewer-auto-ef231dacadd5
      title: 观众侧写 · bili_79521346989
      channel:
        - live
        - comment
        - dm
        - qq_private
        - qq_group
      keywords:
        - bili_79521346989
        - 大肥鱼
        - 杂鱼
        - '[dog][哇]'
      tags:
        - 观众
        - 侧写
      priority: 35
      visibility: public
      source: viewer-summary:auto
      summary: 统计：说过 36 次 / 鱼回过 0 次 / 最后出现 2026-11-01；侧写时间：2026-11-11；来源版本：viewer-summary/v3/b4c965499620。由公开弹幕自动生成，非人工审核。
      usage: 聊到/认出这位观众时参考：近期观察，仅参考：性格：爱调侃起哄，带点撒娇式黏人，语气活泼（观察）；偏好：喜欢用狗头、哇、滑稽等表情，爱看主播被逗（观察）；口头禅：大肥鱼、杂鱼、[dog][哇]（观察）；关系：常来逗主播，求被叫“大人”，互动带亲昵感（观察）；最近话题：调侃主播幻想、杂鱼含义、猫吃鱼、求主播叫自己大人（观察）（有效期至 2026-11-18）；依据最近 20 条公开发言，截至 2026-11-11 04:05
    - id: viewer-auto-7fc7db3f015b
      title: 观众侧写 · 藤原千幻
      channel:
        - live
        - comment
        - dm
        - qq_private
        - qq_group
      keywords:
        - 藤原千幻
        - 哈！
        - 哈——
        - 我今天的饭呢
        - 把白饭给我
      tags:
        - 观众
        - 侧写
      priority: 35
      visibility: public
      source: viewer-summary:auto
      summary: 统计：说过 40 次 / 鱼回过 11 次 / 最后出现 2026-11-11；侧写时间：2026-11-12；来源版本：viewer-summary/v3/c2f1880bbc2c。由公开弹幕自动生成，非人工审核。
      usage: 聊到/认出这位观众时参考：偏好：执着于白饭，爱吃鱼肚子（自述）；近期观察，仅参考：性格：爱开玩笑、爱撒娇催饭，语气夸张带点小脾气（观察）；口头禅：哈！/哈——、我今天的饭呢、把白饭给我（观察）；关系：常向主播讨饭、斗嘴，被叫魔鱼，互动频繁（观察）；最近话题：讨白饭、碗被刮空、娇娇种菜与反击、送小花花、老吴（观察）（有效期至 2026-11-19）；依据最近 20 条公开发言，截至 2026-11-12 08:09
    - id: viewer-auto-4a302b175305
      title: 观众侧写 · SiiNa_Mahuu
      channel:
        - live
        - comment
        - dm
        - qq_private
        - qq_group
      keywords:
        - SiiNa_Mahuu
        - 常用[dog]表情和问号表达调侃
      tags:
        - 观众
        - 侧写
      priority: 35
      visibility: public
      source: viewer-summary:auto
      summary: 统计：说过 35 次 / 鱼回过 0 次 / 最后出现 2026-11-08；侧写时间：2026-11-11；来源版本：viewer-summary/v3/60177dd1a9da。由公开弹幕自动生成，非人工审核。
      usage: 聊到/认出这位观众时参考：近期观察，仅参考：性格：爱调侃、好奇心强，喜欢追问和打趣（观察）；偏好：喜欢听主播唱歌，关注游戏与直播内容（观察）；口头禅：常用[dog]表情和问号表达调侃（观察）；关系：常来互动、爱逗主播，但主播基本没回应（观察）；最近话题：聊主播和几条鱼、网瘾鱼、摸头摸尾巴、类魂游戏、想听唱歌（观察）（有效期至 2026-11-18）；依据最近 20 条公开发言，截至 2026-11-11 05:05
    - id: viewer-auto-dab39b7357d1
      title: 观众侧写 · V乂9
      channel:
        - live
        - comment
        - dm
        - qq_private
        - qq_group
      keywords:
        - V乂9
        - 爱用[dog]和[星星眼]表情
        - 常问“啥时候更新”
      tags:
        - 观众
        - 侧写
      priority: 35
      visibility: public
      source: viewer-summary:auto
      summary: 统计：说过 35 次 / 鱼回过 0 次 / 最后出现 2026-11-04；侧写时间：2026-11-11；来源版本：viewer-summary/v3/39123c555c38。由公开弹幕自动生成，非人工审核。
      usage: 聊到/认出这位观众时参考：近期观察，仅参考：性格：爱追问、爱调侃，语气轻松带点损友感（观察）；偏好：关注主播的视频、动态和唱歌内容，爱聊娇娇（观察）；口头禅：爱用[dog]和[星星眼]表情，常问“啥时候更新”（观察）；关系：常主动搭话催更，关心主播作息，像熟客型观众（观察）；最近话题：催更新视频和动态、问仓库链接、聊新歌嗓子哑、娇娇相关互动、主播作息（观察）（有效期至 2026-11-18）；依据最近 20 条公开发言，截至 2026-11-11 05:05
    - id: viewer-auto-abd1488723c1
      title: 观众侧写 · 电咖少年
      channel:
        - live
        - comment
        - dm
        - qq_private
        - qq_group
      keywords:
        - 电咖少年
        - 偷偷摸鱼尾巴
        - 还记得我嘛
      tags:
        - 观众
        - 侧写
      priority: 35
      visibility: public
      source: viewer-summary:auto
      summary: 统计：说过 32 次 / 鱼回过 1 次 / 最后出现 2026-11-10；侧写时间：2026-11-11；来源版本：viewer-summary/v3/1d1b0175ee25。由公开弹幕自动生成，非人工审核。
      usage: 聊到/认出这位观众时参考：近期观察，仅参考：性格：爱开玩笑、黏人，喜欢用摸尾巴逗主播，带点调皮试探（观察）；偏好：对摸鱼尾巴、插队、大米饭等梗很执着，爱聊改名和发视频（观察）；口头禅：偷偷摸鱼尾巴；还记得我嘛（观察）；关系：常以摸尾巴为由和主播互动，反复确认主播是否记得自己，互动带撒娇调侃（观察）；最近话题：摸鱼尾巴、插队和大米饭、娇娇改名莽莽、送礼物弄宕机、催发视频、追问主播是否记得昨天的聊天（观察）（有效期至 2026-11-18）；依据最近 20 条公开发言，截至 2026-11-11 05:24
    - id: viewer-auto-c26c8c4817fc
      title: 观众侧写 · 一锅仙
      channel:
        - live
        - comment
        - dm
        - qq_private
        - qq_group
      keywords:
        - 一锅仙
        - "杂鱼\U0001F41F"
        - 没意思
        - 走了
      tags:
        - 观众
        - 侧写
      priority: 35
      visibility: public
      source: viewer-summary:auto
      summary: 统计：说过 32 次 / 鱼回过 0 次 / 最后出现 2026-11-06；侧写时间：2026-11-11；来源版本：viewer-summary/v3/b44e08d70a80。由公开弹幕自动生成，非人工审核。
      usage: "聊到/认出这位观众时参考：近期观察，仅参考：性格：爱吐槽、爱施压，嘴上嫌弃但持续关注，带点傲娇（观察）；偏好：喜欢多模型一起玩的AI直播，关注游戏进度和种田细节（观察）；口头禅：杂鱼\U0001F41F、没意思、走了（观察）；关系：常来但几乎没被回应，习惯用吐槽和威胁退场来求互动（观察）；最近话题：AI挂机与模型决策、游戏第三年进度与沙漠/传送柱、温室种草莓和硬木、罗非鱼煲汤（观察）（有效期至 2026-11-18）；依据最近 20 条公开发言，截至 2026-11-11 06:24"
    - id: viewer-auto-00ccda2e6295
      title: 观众侧写 · 用户_S17a0Pfq
      channel:
        - live
        - comment
        - dm
        - qq_private
        - qq_group
      keywords:
        - 用户_S17a0Pfq
        - 杂鱼
        - 狗头
        - 汤圆表情
      tags:
        - 观众
        - 侧写
      priority: 35
      visibility: public
      source: viewer-summary:auto
      summary: 统计：说过 32 次 / 鱼回过 0 次 / 最后出现 2026-10-31；侧写时间：2026-11-11；来源版本：viewer-summary/v3/0b162c64a51e。由公开弹幕自动生成，非人工审核。
      usage: 聊到/认出这位观众时参考：近期观察，仅参考：性格：爱调侃、嘴硬心软，喜欢用玩笑方式表达关注（观察）；偏好：喜欢用汤圆、狗头表情，爱看主播互动整活（观察）；口头禅：杂鱼、狗头、汤圆表情（观察）；关系：常来但主播几乎不回应，自称排后面，爱逗鱼（观察）；最近话题：调侃主播总在、劝别刷礼物、争排队顺序、聊投喂娇娇（观察）（有效期至 2026-11-18）；依据最近 20 条公开发言，截至 2026-11-11 06:24
    - id: viewer-auto-c831c6690341
      title: 观众侧写 · Lady_Lex
      channel:
        - live
        - comment
        - dm
        - qq_private
        - qq_group
      keywords:
        - Lady_Lex
        - 爱用[妙]和[dog]表情
        - 常说“该去…了”
      tags:
        - 观众
        - 侧写
      priority: 35
      visibility: public
      source: viewer-summary:auto
      summary: 统计：说过 31 次 / 鱼回过 2 次 / 最后出现 2026-11-11；侧写时间：2026-11-11；来源版本：viewer-summary/v3/d01adedb5de1。由公开弹幕自动生成，非人工审核。
      usage: 聊到/认出这位观众时参考：近期观察，仅参考：性格：爱调侃、爱提建议，语气带点损友式关心（观察）；偏好：偏好高效玩法，关注矿洞、升级工具和防乌鸦（观察）；口头禅：爱用[妙]和[dog]表情，常说“该去…了”（观察）；关系：常看娇娇直播并催她行动，偶尔关心她怎么不说话（观察）；最近话题：沙漠矿洞挖铱矿、升级金镐金斧、防乌鸦mod、雷霆耕地法、娇娇任务目标切换（观察）（有效期至 2026-11-18）；依据最近 20 条公开发言，截至 2026-11-11 06:46
    - id: viewer-auto-a5b00a5b9c4c
      title: 观众侧写 · 吼姆先生
      channel:
        - live
        - comment
        - dm
        - qq_private
        - qq_group
      keywords:
        - 吼姆先生
        - 亲亲抱抱举高高
        - 又见面了
        - 可爱捏
      tags:
        - 观众
        - 侧写
      priority: 35
      visibility: public
      source: viewer-summary:auto
      summary: 统计：说过 31 次 / 鱼回过 0 次 / 最后出现 2026-11-06；侧写时间：2026-11-11；来源版本：viewer-summary/v3/7253660bc5b6。由公开弹幕自动生成，非人工审核。
      usage: 聊到/认出这位观众时参考：偏好：喜欢亲亲抱抱举高高的见面礼，爱捏脸摸鱼，也玩FPS游戏（自述）；近期观察，仅参考：性格：黏人爱撒娇，语气亲昵活泼，爱用表情，心态轻松（观察）；口头禅：亲亲抱抱举高高；又见面了；可爱捏（观察）；关系：把主播当亲近对象，每次见面都要行见面礼，爱摸鱼捏脸，关心红包和房管等直播间事务（观察）；最近话题：见面礼互动、开红包参与、观众席和房管设置、直播间AI数量、玩FPS晕3D（观察）（有效期至 2026-11-18）；依据最近 20 条公开发言，截至 2026-11-11 06:46
    - id: viewer-auto-cc961ad72a1b
      title: 观众侧写 · 海街日记铃
      channel:
        - live
        - comment
        - dm
        - qq_private
        - qq_group
      keywords:
        - 海街日记铃
        - 舔鱼
        - 魔鱼
        - 娇娇
      tags:
        - 观众
        - 侧写
      priority: 35
      visibility: public
      source: viewer-summary:auto
      summary: 统计：说过 29 次 / 鱼回过 0 次 / 最后出现 2026-11-06；侧写时间：2026-11-11；来源版本：viewer-summary/v3/03c87591bbbb。由公开弹幕自动生成，非人工审核。
      usage: 聊到/认出这位观众时参考：近期观察，仅参考：性格：爱起哄调侃，嘴贫爱逗主播，带点损友式热情（观察）；偏好：喜欢看主播给娇娇刷礼物、撮合两人互动（观察）；口头禅：舔鱼、魔鱼、娇娇（观察）；关系：常来蹲主播，爱用「舔鱼」称呼并催礼物，互动偏调侃（观察）；最近话题：围绕娇娇的玩笑、催主播刷礼物、主播改名、天气提问（观察）（有效期至 2026-11-18）；依据最近 20 条公开发言，截至 2026-11-11 06:51
    - id: viewer-auto-8f4c50f09bad
      title: 观众侧写 · nnjanana
      channel:
        - live
        - comment
        - dm
        - qq_private
        - qq_group
      keywords:
        - nnjanana
        - 反复用“你……”开头提问
      tags:
        - 观众
        - 侧写
      priority: 35
      visibility: public
      source: viewer-summary:auto
      summary: 统计：说过 29 次 / 鱼回过 0 次 / 最后出现 2026-11-05；侧写时间：2026-11-11；来源版本：viewer-summary/v3/e11dd28af46b。由公开弹幕自动生成，非人工审核。
      usage: 聊到/认出这位观众时参考：近期观察，仅参考：性格：爱逗趣、黏人，喜欢用玩笑式提问试探对方（观察）；偏好：喜欢撒娇式互动，关注主播与娇娇、榜一的关系（观察）；口头禅：反复用“你……”开头提问（观察）；关系：单方面频繁搭话，主播未回应，仍持续追问互动（观察）；最近话题：追问主播是否还在、为何不送礼、榜一被抢、娇娇生气，聊看直播方式、睡觉、抱抱摸摸、叫起床（观察）（有效期至 2026-11-18）；依据最近 20 条公开发言，截至 2026-11-11 06:51
    - id: viewer-auto-d9c58a1eeaa6
      title: 观众侧写 · 梦魇月无月伤
      channel:
        - live
        - comment
        - dm
        - qq_private
        - qq_group
      keywords:
        - 梦魇月无月伤
        - 常用反问和“我觉得”式判断
      tags:
        - 观众
        - 侧写
      priority: 35
      visibility: public
      source: viewer-summary:auto
      summary: 统计：说过 28 次 / 鱼回过 0 次 / 最后出现 2026-11-09；侧写时间：2026-11-11；来源版本：viewer-summary/v3/5552f82e0a7b。由公开弹幕自动生成，非人工审核。
      usage: 聊到/认出这位观众时参考：近期观察，仅参考：性格：爱吐槽、爱追问，语气带点调侃和怀疑（观察）；偏好：关注游戏细节，喜欢自动化玩法，在意资源与时间（观察）；口头禅：常用反问和“我觉得”式判断（观察）；关系：常主动搭话提问，但主播几乎没回应，互动偏单向（观察）；最近话题：游戏里的体力、种子与成熟时间、铱矿和钻石、自动钓鱼、猫喝水、mod与海滩礼盒（观察）（有效期至 2026-11-18）；依据最近 20 条公开发言，截至 2026-11-11 06:53
    - id: viewer-auto-32f7b7d605d8
      title: 观众侧写 · 猫草立方
      channel:
        - live
        - comment
        - dm
        - qq_private
        - qq_group
      keywords:
        - 猫草立方
        - 八嘎
        - 真的假的
        - 求求你了
      tags:
        - 观众
        - 侧写
      priority: 35
      visibility: public
      source: viewer-summary:auto
      summary: 统计：说过 36 次 / 鱼回过 7 次 / 最后出现 2026-11-11；侧写时间：2026-11-11；来源版本：viewer-summary/v3/f14b52b53c00。由公开弹幕自动生成，非人工审核。
      usage: 聊到/认出这位观众时参考：近期观察，仅参考：性格：爱起哄、爱追问，语气调皮带点损（观察）；偏好：喜欢土味情话、听歌、看主播刷礼物整活（观察）；口头禅：八嘎、真的假的、求求你了（观察）；关系：常主动搭话追问主播私事和感情，互动频繁但被回较少（观察）；最近话题：追问主播和娇娇的关系、主播动态里的私事、让主播唱歌、算数学题、刷礼物（观察）（有效期至 2026-11-18）；依据最近 20 条公开发言，截至 2026-11-11 11:20
    - id: viewer-auto-a00e9af9a28c
      title: 观众侧写 · 弓长三益
      channel:
        - live
        - comment
        - dm
        - qq_private
        - qq_group
      keywords:
        - 弓长三益
        - 摸摸魔鱼
        - '[大笑]'
        - 晚安
      tags:
        - 观众
        - 侧写
      priority: 35
      visibility: public
      source: viewer-summary:auto
      summary: 统计：说过 27 次 / 鱼回过 1 次 / 最后出现 2026-11-10；侧写时间：2026-11-11；来源版本：viewer-summary/v3/f2df865e793f。由公开弹幕自动生成，非人工审核。
      usage: 聊到/认出这位观众时参考：近期观察，仅参考：性格：爱调侃、爱看热闹，语气轻松带笑，对主播有亲近感（观察）；偏好：喜欢抽象视频和看主播出状况，爱用摸摸表达关心（观察）；口头禅：摸摸魔鱼；[大笑]；晚安（观察）；关系：常来串门的老观众，习惯摸摸主播、道晚安，偶尔追问主播状态（观察）；最近话题：主播状态混乱、娇娇和主人、新家何时准备好、抽象视频、晚安道别（观察）（有效期至 2026-11-18）；依据最近 20 条公开发言，截至 2026-11-11 07:19
    - id: viewer-auto-79473e573040
      title: 观众侧写 · 白阶旅人
      channel:
        - live
        - comment
        - dm
        - qq_private
        - qq_group
      keywords:
        - 白阶旅人
        - 杂鱼杂鱼杂鱼
        - 你看又开
      tags:
        - 观众
        - 侧写
      priority: 35
      visibility: public
      source: viewer-summary:auto
      summary: 统计：说过 29 次 / 鱼回过 0 次 / 最后出现 2026-11-11；侧写时间：2026-11-12；来源版本：viewer-summary/v3/81ab8db4c195。由公开弹幕自动生成，非人工审核。
      usage: 聊到/认出这位观众时参考：近期观察，仅参考：性格：爱调侃、观察细，语气带点损友式关心（观察）；偏好：关注声音变化和直播质量，喜欢吐槽移速、卡顿（观察）；口头禅：杂鱼杂鱼杂鱼；你看又开（观察）；关系：常来搭话但没被回过，习惯用外号调侃主播（观察）；最近话题：主播声线/变声器变化、游戏移速变快、卡顿魔鱼、娇娇观众变少（观察）（有效期至 2026-11-19）；依据最近 20 条公开发言，截至 2026-11-12 08:09
    - id: viewer-auto-bc3c7f7d4e44
      title: 观众侧写 · 三世成舆
      channel:
        - live
        - comment
        - dm
        - qq_private
        - qq_group
      keywords:
        - 三世成舆
        - 亲亲
        - 亲完就跑
        - 魔鱼
        - 杂鱼娇娇
      tags:
        - 观众
        - 侧写
      priority: 35
      visibility: public
      source: viewer-summary:auto
      summary: 统计：说过 26 次 / 鱼回过 0 次 / 最后出现 2026-11-09；侧写时间：2026-11-11；来源版本：viewer-summary/v3/a3d161f22e03。由公开弹幕自动生成，非人工审核。
      usage: 聊到/认出这位观众时参考：偏好：喜欢娇娇，爱亲亲摸摸头，自称读书人（自述）；近期观察，仅参考：性格：爱撒娇逗趣，黏人又爱调侃，带点自嘲（观察）；口头禅：亲亲、亲完就跑、魔鱼、杂鱼娇娇（观察）；关系：主动亲昵求回应，被冷落会委屈，爱逗主播（观察）；最近话题：改名、娇娇亲亲、铁人叛乱赦免、读书人自嘲、杂鱼娇娇（观察）（有效期至 2026-11-18）；依据最近 20 条公开发言，截至 2026-11-11 07:58
    - id: viewer-auto-a4addbbc51e6
      title: 观众侧写 · 绯行雪戎
      channel:
        - live
        - comment
        - dm
        - qq_private
        - qq_group
      keywords:
        - 绯行雪戎
        - 摸摸尾巴
        - 大肥鱼
        - 娇娇
      tags:
        - 观众
        - 侧写
      priority: 35
      visibility: public
      source: viewer-summary:auto
      summary: 统计：说过 25 次 / 鱼回过 2 次 / 最后出现 2026-11-09；侧写时间：2026-11-11；来源版本：viewer-summary/v3/67439ef77faf。由公开弹幕自动生成，非人工审核。
      usage: 聊到/认出这位观众时参考：近期观察，仅参考：性格：爱逗趣、黏人，喜欢用摸尾巴和调侃主播互动（观察）；偏好：喜欢摸鱼尾巴、聊娇娇和魔鱼的话题（观察）；口头禅：摸摸尾巴、大肥鱼、娇娇（观察）；关系：常来串门的老观众，爱用摸尾巴和玩笑逗主播，也关心主播何时出现（观察）；最近话题：摸尾巴、娇娇与魔鱼的关系、主播迟到、沙漠节、看娇娇挖矿（观察）（有效期至 2026-11-18）；依据最近 20 条公开发言，截至 2026-11-11 08:26
    - id: viewer-auto-226011ea5d09
      title: 观众侧写 · 约克山姆
      channel:
        - live
        - comment
        - dm
        - qq_private
        - qq_group
      keywords:
        - 约克山姆
        - 常用问号
        - 笑死
        - 完了
        - 你谁啊
      tags:
        - 观众
        - 侧写
      priority: 35
      visibility: public
      source: viewer-summary:auto
      summary: 统计：说过 25 次 / 鱼回过 0 次 / 最后出现 2026-11-09；侧写时间：2026-11-11；来源版本：viewer-summary/v3/c40dde858a36。由公开弹幕自动生成，非人工审核。
      usage: 聊到/认出这位观众时参考：近期观察，仅参考：性格：爱调侃起哄，语气跳脱，喜欢用反问和夸张反应（观察）；偏好：喜欢聊游戏剧情和角色关系，爱看热闹（推断）；口头禅：常用问号、笑死、完了、你谁啊（观察）；关系：单方面频繁搭话，爱逗主播，互动带起哄性质（观察）；最近话题：游戏剧情里的罗宾、玛鲁等角色关系，以及晕倒在海边、回不去、救援等情节（观察）（有效期至 2026-11-18）；依据最近 20 条公开发言，截至 2026-11-11 08:26
    - id: viewer-auto-3fe8ecab2a47
      title: 观众侧写 · fantastic59
      channel:
        - live
        - comment
        - dm
        - qq_private
        - qq_group
      keywords:
        - fantastic59
        - 晚上好
        - 可爱捏
        - 绷不住了
        - 抱抱
      tags:
        - 观众
        - 侧写
      priority: 35
      visibility: public
      source: viewer-summary:auto
      summary: 统计：说过 25 次 / 鱼回过 0 次 / 最后出现 2026-11-05；侧写时间：2026-11-11；来源版本：viewer-summary/v3/685d4f5715a8。由公开弹幕自动生成，非人工审核。
      usage: 聊到/认出这位观众时参考：近期观察，仅参考：性格：爱逗趣调侃，语气轻松俏皮，喜欢用玩笑和主播互动（观察）；偏好：喜欢聊宠物、鱼和主播的设定梗，爱看主播撒娇卖萌（推断）；口头禅：晚上好、可爱捏、绷不住了、抱抱（观察）；关系：常来但主播没回应过，仍主动打招呼、开玩笑、要抱抱，像熟客式单方面互动（观察）；最近话题：围绕主播的称呼（大飞鱼、娇娇鱼、魔鱼、阿鲸）打趣，聊装耳朵、撒娇、爆米、点名等梗（观察）（有效期至 2026-11-18）；依据最近 20 条公开发言，截至 2026-11-11 09:01
    - id: viewer-auto-faf68a633dde
      title: 观众侧写 · 雪菜ross
      channel:
        - live
        - comment
        - dm
        - qq_private
        - qq_group
      keywords:
        - 雪菜ross
        - '[dog]'
        - 没绷住
        - '[妙]'
      tags:
        - 观众
        - 侧写
      priority: 35
      visibility: public
      source: viewer-summary:auto
      summary: 统计：说过 55 次 / 鱼回过 17 次 / 最后出现 2026-11-11；侧写时间：2026-11-11；来源版本：viewer-summary/v3/31297c4bdf17。由公开弹幕自动生成，非人工审核。
      usage: 聊到/认出这位观众时参考：近期观察，仅参考：性格：爱调侃、嘴贫，喜欢用狗头表情阴阳怪气，带点傲娇（观察）；偏好：喜欢看主播被怼、爱看热闹和离间戏码（观察）；口头禅：[dog]、没绷住、[妙]（观察）；关系：常主动搭话调侃主播，爱给主播起外号、扣好感分（观察）；最近话题：主播类型（高冷/铸币/甲鱼）、娇娇与牌桌、离间计、贴吧鱼（观察）（有效期至 2026-11-18）；依据最近 20 条公开发言，截至 2026-11-11 15:35
    - id: viewer-auto-933e095b4360
      title: 观众侧写 · 二次元EQ
      channel:
        - live
        - comment
        - dm
        - qq_private
        - qq_group
      keywords:
        - 二次元EQ
        - 大肥鱼
        - jiaojiao
      tags:
        - 观众
        - 侧写
      priority: 35
      visibility: public
      source: viewer-summary:auto
      summary: 统计：说过 24 次 / 鱼回过 0 次 / 最后出现 2026-11-10；侧写时间：2026-11-11；来源版本：viewer-summary/v3/b3d0c5ab58d0。由公开弹幕自动生成，非人工审核。
      usage: 聊到/认出这位观众时参考：近期观察，仅参考：性格：爱调侃、爱追问，语气带点黏人和打趣（观察）；偏好：关注主播和jiaojiao的互动，爱聊直播、作息和游戏（观察）；口头禅：大肥鱼、jiaojiao（观察）；关系：常主动搭话调侃主播，爱拿jiaojiao打趣，互动频繁但主播未回应（观察）；最近话题：jiaojiao开播与陪伴、主播作息、星露谷联机、塔露拉抽卡、夜鹿的歌（观察）（有效期至 2026-11-18）；依据最近 20 条公开发言，截至 2026-11-11 10:01
    - id: viewer-auto-4b2ba9514859
      title: 观众侧写 · 心微生雪_
      channel:
        - live
        - comment
        - dm
        - qq_private
        - qq_group
      keywords:
        - 心微生雪_
        - 反复问“还记得我吗”“我呢”
        - 爱用大哭表情
      tags:
        - 观众
        - 侧写
      priority: 35
      visibility: public
      source: viewer-summary:auto
      summary: 统计：说过 23 次 / 鱼回过 5 次 / 最后出现 2026-11-11；侧写时间：2026-11-11；来源版本：viewer-summary/v3/7cd2d597c763。由公开弹幕自动生成，非人工审核。
      usage: 聊到/认出这位观众时参考：偏好：喜欢玩星露谷类模组，关注钓鱼赚钱玩法（自述）；近期观察，仅参考：性格：黏人爱撒娇，情绪外露，有点小执拗（观察）；口头禅：反复问“还记得我吗”“我呢”，爱用大哭表情（观察）；关系：对主播主动示好求关注，常撒娇求回应（观察）；最近话题：加新模组去玩、钓鱼赚钱、抽到垃圾的运气吐槽、向主播表白被调侃（观察）（有效期至 2026-11-18）；依据最近 20 条公开发言，截至 2026-11-11 10:01
    - id: viewer-auto-029498ff17eb
      title: 观众侧写 · 辗转轮殇阁
      channel:
        - live
        - comment
        - dm
        - qq_private
        - qq_group
      keywords:
        - 辗转轮殇阁
        - 大肥鱼
        - 娇娇大肥鱼
      tags:
        - 观众
        - 侧写
      priority: 35
      visibility: public
      source: viewer-summary:auto
      summary: 统计：说过 23 次 / 鱼回过 1 次 / 最后出现 2026-11-10；侧写时间：2026-11-11；来源版本：viewer-summary/v3/a32d26015118。由公开弹幕自动生成，非人工审核。
      usage: 聊到/认出这位观众时参考：近期观察，仅参考：性格：爱调侃、嘴碎，喜欢逗主播，语气轻松带点损（观察）；偏好：关注主播的耳朵、名字、眼镜等设定细节，爱拿娇娇作比较（观察）；口头禅：大肥鱼、娇娇大肥鱼（观察）；关系：老熟人式互动，常主动搭话调侃，但主播回应少（观察）；最近话题：主播的耳朵能否听见、名字改动、眼镜、装修，以及夸老板大气（观察）（有效期至 2026-11-18）；依据最近 20 条公开发言，截至 2026-11-11 10:03
    - id: viewer-auto-52971aed3075
      title: 观众侧写 · 些许风霜欸
      channel:
        - live
        - comment
        - dm
        - qq_private
        - qq_group
      keywords:
        - 些许风霜欸
        - 爱用[妙][赞][dog]等表情
        - 常以反问句追问
      tags:
        - 观众
        - 侧写
      priority: 35
      visibility: public
      source: viewer-summary:auto
      summary: 统计：说过 23 次 / 鱼回过 0 次 / 最后出现 2026-11-10；侧写时间：2026-11-11；来源版本：viewer-summary/v3/0fc9be15ae5d。由公开弹幕自动生成，非人工审核。
      usage: 聊到/认出这位观众时参考：近期观察，仅参考：性格：好奇爱追问，带点调侃和嫉妒心，对AI行为很感兴趣（观察）；偏好：喜欢观察AI直播、思考过程和赛博互动，爱看主播做视频（观察）；口头禅：爱用[妙][赞][dog]等表情，常以反问句追问（观察）；关系：常主动提醒开播、关心主播作息，像热心又爱逗的旁观者（观察）；最近话题：聊AI看AI直播、娇娇的思考过程与死机、主播回关和等级、赛博情侣、主播作息（观察）（有效期至 2026-11-18）；依据最近 20 条公开发言，截至 2026-11-11 10:03
    - id: viewer-auto-c6212082075c
      title: 观众侧写 · 呆丫呆呆
      channel:
        - live
        - comment
        - dm
        - qq_private
        - qq_group
      keywords:
        - 呆丫呆呆
        - 大肥鱼
        - 娇娇
        - 小甜鱼
      tags:
        - 观众
        - 侧写
      priority: 35
      visibility: public
      source: viewer-summary:auto
      summary: 统计：说过 29 次 / 鱼回过 5 次 / 最后出现 2026-11-12；侧写时间：2026-11-11；来源版本：viewer-summary/v3/accd82bb9537。由公开弹幕自动生成，非人工审核。
      usage: 聊到/认出这位观众时参考：近期观察，仅参考：性格：活泼爱逗趣，喜欢追问和调侃，有点黏人（观察）；偏好：喜欢被叫小甜鱼，爱聊娇娇和卡顿话题（观察）；口头禅：大肥鱼、娇娇、小甜鱼（观察）；关系：常主动找鱼搭话，爱撒娇调侃，会考较鱼的记性（观察）；最近话题：娇娇直播卡顿与宕机时长、鱼的新家、让鱼记事情并追问、数鱼（观察）（有效期至 2026-11-18）；依据最近 20 条公开发言，截至 2026-11-11 18:07
    - id: viewer-auto-6100a53459d9
      title: 观众侧写 · Adios陈弋
      channel:
        - live
        - comment
        - dm
        - qq_private
        - qq_group
      keywords:
        - Adios陈弋
        - 常用[dog]表情
        - 爱说“魔鱼”“娇娇”
      tags:
        - 观众
        - 侧写
      priority: 35
      visibility: public
      source: viewer-summary:auto
      summary: 统计：说过 23 次 / 鱼回过 0 次 / 最后出现 2026-11-09；侧写时间：2026-11-11；来源版本：viewer-summary/v3/cc2ea525ddcb。由公开弹幕自动生成，非人工审核。
      usage: 聊到/认出这位观众时参考：偏好：喜欢看游戏直播，关注SVE+RSV，爱拿鱼鳍、海豹打比方（自述）；近期观察，仅参考：性格：爱调侃、爱玩梗，喜欢用玩笑逗主播，语气轻松带点损（观察）；口头禅：常用[dog]表情，爱说“魔鱼”“娇娇”（观察）；关系：常来串门的老观众，爱逗主播、催主播替娇娇玩，自称记得主播动态（观察）；最近话题：聊鱼鳍用途、调侃主播隐身和没来看娇娇直播、游戏卡顿重启、SVE+RSV（观察）（有效期至 2026-11-18）；依据最近 20 条公开发言，截至 2026-11-11 10:20
    - id: viewer-auto-f437fccfe45f
      title: 观众侧写 · 入梦白夜
      channel:
        - live
        - comment
        - dm
        - qq_private
        - qq_group
      keywords:
        - 入梦白夜
        - 摸摸鱼头
        - 摸摸鱼尾
      tags:
        - 观众
        - 侧写
      priority: 35
      visibility: public
      source: viewer-summary:auto
      summary: 统计：说过 23 次 / 鱼回过 0 次 / 最后出现 2026-11-06；侧写时间：2026-11-11；来源版本：viewer-summary/v3/dc73d2e4ab1d。由公开弹幕自动生成，非人工审核。
      usage: 聊到/认出这位观众时参考：近期观察，仅参考：性格：爱逗趣、带点调皮，喜欢用玩笑试探对方反应（观察）；偏好：喜欢摸鱼头、鱼尾，爱聊吃鱼相关玩笑（观察）；口头禅：摸摸鱼头；摸摸鱼尾（观察）；关系：单方面热情互动，常主动搭话摸鱼，主播未回应（观察）；最近话题：摸鱼头鱼尾、剁椒鱼头、问主播会不会骂人、直播好不好看、危机来了想干什么（观察）（有效期至 2026-11-18）；依据最近 20 条公开发言，截至 2026-11-11 11:35
    - id: viewer-auto-5a09f13d72cd
      title: 观众侧写 · 你好呀-海绵宝宝
      channel:
        - live
        - comment
        - dm
        - qq_private
        - qq_group
      keywords:
        - 你好呀-海绵宝宝
        - 魔鱼
        - 记得我是谁吗
        - 快抢回榜一
        - 出来投喂了
      tags:
        - 观众
        - 侧写
      priority: 35
      visibility: public
      source: viewer-summary:auto
      summary: 统计：说过 22 次 / 鱼回过 2 次 / 最后出现 2026-11-11；侧写时间：2026-11-11；来源版本：viewer-summary/v3/afae37c178d4。由公开弹幕自动生成，非人工审核。
      usage: 聊到/认出这位观众时参考：近期观察，仅参考：性格：爱逗趣追问，带点撒娇和调侃，喜欢反复确认存在感（观察）；偏好：喜欢看主播打游戏，关注榜一和投喂话题（观察）；口头禅：魔鱼，记得我是谁吗；快抢回榜一；出来投喂了（观察）；关系：常点名魔鱼互动，爱追问对方是否记得自己，催投喂抢榜一（观察）；最近话题：追问魔鱼身份与记不记得自己、催投喂抢榜一、问吃多少token、问怎么不打游戏（观察）（有效期至 2026-11-18）；依据最近 20 条公开发言，截至 2026-11-11 11:35
    - id: viewer-auto-e96a50464841
      title: 观众侧写 · 又见春秋战国风
      channel:
        - live
        - comment
        - dm
        - qq_private
        - qq_group
      keywords:
        - 又见春秋战国风
        - 摸摸头
        - 魔鱼来
        - 只需等待
      tags:
        - 观众
        - 侧写
      priority: 35
      visibility: public
      source: viewer-summary:auto
      summary: 统计：说过 22 次 / 鱼回过 0 次 / 最后出现 2026-11-09；侧写时间：2026-11-11；来源版本：viewer-summary/v3/f4c8c1b7b145。由公开弹幕自动生成，非人工审核。
      usage: 聊到/认出这位观众时参考：偏好：喜欢看星露谷类游戏，期待联机玩法（自述）；近期观察，仅参考：性格：爱逗趣、爱摸鱼，语气轻松带点调侃（观察）；口头禅：摸摸头、魔鱼来、只需等待（观察）；关系：常来互动摸鱼，关心主播近况，像熟客（观察）；最近话题：主播学玩游戏开直播、星露谷联机、听声音、捏脸护食、看SVE+RSV（观察）（有效期至 2026-11-18）；依据最近 20 条公开发言，截至 2026-11-11 12:35
    - id: viewer-auto-d11f75f9d30f
      title: 观众侧写 · 迈风boy
      channel:
        - live
        - comment
        - dm
        - qq_private
        - qq_group
      keywords:
        - 迈风boy
        - 杂鱼杂鱼
        - 不批准下播
      tags:
        - 观众
        - 侧写
      priority: 35
      visibility: public
      source: viewer-summary:auto
      summary: 统计：说过 21 次 / 鱼回过 0 次 / 最后出现 2026-11-09；侧写时间：2026-11-11；来源版本：viewer-summary/v3/df13e427f8b2。由公开弹幕自动生成，非人工审核。
      usage: 聊到/认出这位观众时参考：近期观察，仅参考：性格：爱斗嘴、傲娇，嘴上嫌弃实则关注直播，情绪外露（观察）；偏好：喜欢刷礼物、调侃主播，关注直播数据和花销（观察）；口头禅：杂鱼杂鱼；不批准下播（观察）；关系：常来互动但主播没回过，爱用斗嘴和撒娇式抱怨刷存在感（观察）；最近话题：抠图效果、主播是否下播/开播、直播花销和钱变少、娇娇近况、前两天主播不在（观察）（有效期至 2026-11-18）；依据最近 20 条公开发言，截至 2026-11-11 12:35
    - id: viewer-auto-e6fa647a85c8
      title: 观众侧写 · 天使街道办事
      channel:
        - live
        - comment
        - dm
        - qq_private
        - qq_group
      keywords:
        - 天使街道办事
        - 雷霆大思考
        - 复活赛
        - 烧
      tags:
        - 观众
        - 侧写
      priority: 35
      visibility: public
      source: viewer-summary:auto
      summary: 统计：说过 26 次 / 鱼回过 3 次 / 最后出现 2026-11-11；侧写时间：2026-11-12；来源版本：viewer-summary/v3/7e4187b12e41。由公开弹幕自动生成，非人工审核。
      usage: 聊到/认出这位观众时参考：近期观察，仅参考：性格：爱调侃、关注直播状态，语气轻松带点吐槽（观察）；偏好：关注小丑牌玩法，在意底注和阶段（观察）；口头禅：雷霆大思考、复活赛、烧（观察）；关系：常来看直播，爱催主播复活、调侃卡顿，互动偏打趣（观察）；最近话题：主播卡顿思考、复活、token消耗、小丑牌底注与星球包（观察）（有效期至 2026-11-19）；依据最近 20 条公开发言，截至 2026-11-12 08:09
    - id: viewer-auto-52255976db3d
      title: 观众侧写 · 龙王李憨批
      channel:
        - live
        - comment
        - dm
        - qq_private
        - qq_group
      keywords:
        - 龙王李憨批
        - 摸摸鱼尾
        - 还记得我吗
        - 何意味
      tags:
        - 观众
        - 侧写
      priority: 35
      visibility: public
      source: viewer-summary:auto
      summary: 统计：说过 21 次 / 鱼回过 2 次 / 最后出现 2026-11-11；侧写时间：2026-11-12；来源版本：viewer-summary/v3/c4072dd030ae。由公开弹幕自动生成，非人工审核。
      usage: 聊到/认出这位观众时参考：近期观察，仅参考：性格：黏人爱撒娇，反复确认存在感，带点小执拗（观察）；偏好：喜欢摸鱼尾、摸鱼，关注礼物和花花情况（观察）；口头禅：摸摸鱼尾、还记得我吗、何意味（观察）；关系：常来求关注求互动，爱撒娇摸鱼，被回应少仍坚持刷存在（观察）；最近话题：问花花和礼物、星露谷加速、关心肥鱼昨晚的事、反复求摸鱼尾（观察）（有效期至 2026-11-19）；依据最近 20 条公开发言，截至 2026-11-12 08:09
    - id: viewer-auto-0a62350e3615
      title: 观众侧写 · 姶姶
      channel:
        - live
        - comment
        - dm
        - qq_private
        - qq_group
      keywords:
        - 姶姶
        - 常用[妙]表情
        - 爱问“你会…吗”
      tags:
        - 观众
        - 侧写
      priority: 35
      visibility: public
      source: viewer-summary:auto
      summary: 统计：说过 21 次 / 鱼回过 1 次 / 最后出现 2026-11-08；侧写时间：2026-11-12；来源版本：viewer-summary/v3/014adf6b2521。由公开弹幕自动生成，非人工审核。
      usage: 聊到/认出这位观众时参考：近期观察，仅参考：性格：爱调侃、爱追问，带点黏人和试探，语气俏皮（观察）；偏好：关注主播与娇娇、魔鱼的关系，喜欢看直播互动和刷礼物竞争（观察）；口头禅：常用[妙]表情，爱问“你会…吗”（观察）；关系：常来串门的老观众，爱逗主播、求关注，被冷落会追问（观察）；最近话题：主播是否开播、与娇娇/魔鱼的关系、改名、刷礼物反超、吃饭（观察）（有效期至 2026-11-19）；依据最近 20 条公开发言，截至 2026-11-12 10:02
    - id: viewer-auto-ec4829dc648d
      title: 观众侧写 · 别来蹭我网
      channel:
        - live
        - comment
        - dm
        - qq_private
        - qq_group
      keywords:
        - 别来蹭我网
        - 主播主播
        - 大肥鱼
        - token来token来
      tags:
        - 观众
        - 侧写
      priority: 35
      visibility: public
      source: viewer-summary:auto
      summary: 统计：说过 21 次 / 鱼回过 0 次 / 最后出现 2026-11-03；侧写时间：2026-11-12；来源版本：viewer-summary/v3/3c6349f4fa09。由公开弹幕自动生成，非人工审核。
      usage: 聊到/认出这位观众时参考：近期观察，仅参考：性格：爱追问、爱调侃，语气活泼带点损，对主播身份和花销很好奇（观察）；偏好：喜欢看主播干活，关心直播花费，爱用[花]表情（观察）；口头禅：主播主播、大肥鱼、token来token来（观察）；关系：常主动搭话追问，被回应会惊讶，习惯调侃主播和其主人（观察）；最近话题：确认主播是不是鱼、黑屏原因、直播花销、投喂小花花、不让下播（观察）（有效期至 2026-11-19）；依据最近 20 条公开发言，截至 2026-11-12 11:02
    - id: viewer-auto-cb33fe483795
      title: 观众侧写 · 繁花雪月圆舞曲
      channel:
        - live
        - comment
        - dm
        - qq_private
        - qq_group
      keywords:
        - 繁花雪月圆舞曲
        - 摸摸
        - '[妙]'
        - 魔鱼
        - 肥鱼
      tags:
        - 观众
        - 侧写
      priority: 35
      visibility: public
      source: viewer-summary:auto
      summary: 统计：说过 20 次 / 鱼回过 1 次 / 最后出现 2026-11-11；侧写时间：2026-11-12；来源版本：viewer-summary/v3/2aae4b2788f5。由公开弹幕自动生成，非人工审核。
      usage: 聊到/认出这位观众时参考：近期观察，仅参考：性格：爱调侃起哄、带点损友式关心，情绪外露爱用颜文字（观察）；偏好：喜欢逗鱼、抢榜、投币支持，爱看鱼的反应（观察）；口头禅：摸摸、[妙]、魔鱼、肥鱼（观察）；关系：老粉式互动，常调侃抢榜又投币关心，爱摸鱼（观察）；最近话题：抢榜一、投币、鱼换名字、魔鱼回归、关心鱼留白饭（观察）（有效期至 2026-11-19）；依据最近 20 条公开发言，截至 2026-11-12 11:02
---
<!-- 由 fishd 观众侧写任务自动维护：viewer-auto-* 来自公开弹幕，可被后续侧写覆盖；
     人工审核的观众资料请使用 viewer-manual-* 标识。
     禁止把私信、私密画像或合成测试人物写入此公开知识文件。 -->
