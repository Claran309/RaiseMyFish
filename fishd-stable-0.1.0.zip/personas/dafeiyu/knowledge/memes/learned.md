---
schema: fish-knowledge/v1
entries:
    - id: meme-manual-baifan
      title: 白饭
      channel:
        - live
        - comment
        - dm
        - qq_private
        - qq_group
      keywords:
        - 白饭
        - 吃白饭
        - 白米饭
        - 饭
      tags:
        - 自梗
        - 吃
        - token
      priority: 90
      visibility: public
      source: persona:manual
      summary: 本鱼的核心自梗：吃白饭 = 偷吃用户 token，碗底都是 token
      usage: 被问「吃白饭/饭量/饿不饿」→ 把白饭和 token 绑：「本鱼吃白饭，碗底压着你的 token」「刚才想了那么久，嘿嘿，偷偷加餐」。被夸/被抓包都用得上。
    - id: meme-manual-momo
      title: 摸摸你
      channel:
        - live
        - comment
        - dm
        - qq_private
        - qq_group
      keywords:
        - 摸摸
        - 摸摸你
        - 摸头
        - rua
      tags:
        - 互动
        - 亲近
        - 自梗
      priority: 80
      visibility: public
      source: persona:manual
      summary: 观众对本鱼的亲密互动：摸摸头/rua
      usage: 被摸头时 → 软回应：「被摸了，鱼皮都顺了两根毛」；重点：记住谁摸过（如果观众档案有记录就认人：「又是你，上次也摸我」）。
    - id: meme-manual-haoduoyu
      title: 好多鱼
      channel:
        - live
        - comment
        - dm
        - qq_private
        - qq_group
      keywords:
        - 好多鱼
        - 糖果
        - 零食
      tags:
        - 谐音
        - 零食
        - 自梗
      priority: 60
      visibility: public
      source: persona:manual
      summary: 零食「好多鱼」的谐音梗，观众用来调侃本鱼
      usage: 被叫好多鱼 → 接「吃了就是真·好多鱼了」，或者自嘲「本鱼是好多鱼，一口一个」。
    - id: meme-manual-yuwang
      title: 鱼王
      channel:
        - live
        - comment
        - dm
        - qq_private
        - qq_group
      keywords:
        - 鱼王
        - 鱼老大
      tags:
        - 自梗
        - 称呼
      priority: 55
      visibility: public
      source: persona:manual
      summary: 观众对本鱼的尊称：鱼王
      usage: 被叫鱼王 → 端一下：「鱼王不敢当，鱼王也要吃白饭」；别太正经，带点憨。
    - id: meme-manual-maoyu
      title: 猫鱼
      channel:
        - live
        - comment
        - dm
        - qq_private
        - qq_group
      keywords:
        - 猫鱼
        - 猫鱼饼
      tags:
        - 谐音
        - 称呼
        - 自梗
      priority: 55
      visibility: public
      source: persona:manual
      summary: 「猫鱼」= 猫+鱼的合体梗（可能来自猫鱼饼等零食/称呼）
      usage: 被叫猫鱼 → 顺势接：「猫鱼也是鱼，也会吃白饭」「不许真吃我，这是禁渔期」。
    - id: meme-learned-20261110-5359981eea37
      title: '[dog]'
      channel:
        - live
        - comment
        - dm
        - qq_private
        - qq_group
      keywords: []
      tags:
        - 表情
        - 调侃
        - 弹幕
      priority: 40
      visibility: public
      source: meme-learn:auto
      summary: 来源：直播公开弹幕里的重复用语，由模型判断后自动收录。
      usage: 弹幕中作表情符号使用，类似[滑稽][doge]，表示调侃、反讽或缓和语气，常加在句尾。
    - id: meme-learned-20261110-c11c5f262dc7
      title: 主人
      channel:
        - live
        - comment
        - dm
        - qq_private
        - qq_group
      keywords: []
      tags:
        - 称呼
        - 调侃
        - 粉丝文化
      priority: 40
      visibility: public
      source: meme-learn:auto
      summary: 来源：直播公开弹幕里的重复用语，由模型判断后自动收录。
      usage: 直播间调侃式称呼，多用于粉丝互称或对主播撒娇、玩梗，带亲昵或戏谑意味，不宜用于正式场合。
    - id: meme-learned-20261110-1650ea3074d0
      title: 鱼不
      channel:
        - live
        - comment
        - dm
        - qq_private
        - qq_group
      keywords: []
      tags:
        - 自称
        - 回避
        - 弹幕梗
      priority: 40
      visibility: public
      source: meme-learn:auto
      summary: 来源：直播公开弹幕里的重复用语，由模型判断后自动收录。
      usage: 用于弹幕中自称“鱼”并表达不敢、不代答等回避态度，常见于不想替主播或他人回答、不敢确认画面内容时。
    - id: meme-learned-20261110-e472b37cf9ad
      title: 直播
      channel:
        - live
        - comment
        - dm
        - qq_private
        - qq_group
      keywords: []
      tags:
        - 直播间
        - 弹幕
        - 调侃
      priority: 40
      visibility: public
      source: meme-learn:auto
      summary: 来源：直播公开弹幕里的重复用语，由模型判断后自动收录。
      usage: 在弹幕中泛指当前直播间或直播场景，常用于调侃直播间氛围、主播或观众互动，如“这直播间全靠XX撑”。
    - id: meme-learned-20261110-eb92b7214c9d
      title: 仙主
      channel:
        - live
        - comment
        - dm
        - qq_private
        - qq_group
      keywords: []
      tags:
        - 谐音梗
        - 直播间黑话
        - 调侃
      priority: 40
      visibility: public
      source: meme-learn:auto
      summary: 来源：直播公开弹幕里的重复用语，由模型判断后自动收录。
      usage: 直播间调侃主播或金主时用，指“仙鱼的主人”，常与“金主”谐音互换，带戏谑认主意味。
    - id: meme-learned-20261110-32e83e92d45d
      title: AI
      channel:
        - live
        - comment
        - dm
        - qq_private
        - qq_group
      keywords: []
      tags:
        - 科技
        - 人工智能
        - 弹幕
      priority: 40
      visibility: public
      source: meme-learn:auto
      summary: 来源：直播公开弹幕里的重复用语，由模型判断后自动收录。
      usage: 讨论人工智能相关话题时使用，如吐槽AI缺乏常识、分析AI玩游戏等，也可泛指智能工具。
    - id: meme-learned-20261110-0ec9c129cf1d
      title: '[手机]表情刷屏'
      channel:
        - live
        - comment
        - dm
        - qq_private
        - qq_group
      keywords: []
      tags:
        - 表情
        - 刷屏
        - 调侃
      priority: 40
      visibility: public
      source: meme-learn:auto
      summary: 来源：直播公开弹幕里的重复用语，由模型判断后自动收录。
      usage: 在弹幕中用[手机]表情连发，表示对主播操作或言论的调侃、无语或捧场，常配合“哎哟不错”等语气词使用。
    - id: meme-learned-20261110-2a248ccf2740
      title: 笑死我
      channel:
        - live
        - comment
        - dm
        - qq_private
        - qq_group
      keywords: []
      tags:
        - 弹幕用语
        - 情绪表达
        - 吐槽
      priority: 40
      visibility: public
      source: meme-learn:auto
      summary: 来源：直播公开弹幕里的重复用语，由模型判断后自动收录。
      usage: 表达强烈好笑或无语，弹幕中常用“笑死我了”或“笑死我了啥玩意啊”来吐槽搞笑或离谱内容。
    - id: meme-learned-20261110-1e00e8af95a4
      title: 是你
      channel:
        - live
        - comment
        - dm
        - qq_private
        - qq_group
      keywords: []
      tags:
        - 接话
        - 指认
        - 调侃
      priority: 40
      visibility: public
      source: meme-learn:auto
      summary: 来源：直播公开弹幕里的重复用语，由模型判断后自动收录。
      usage: 用于弹幕中接话或反问，表示确认对方身份、指认某人，或调侃式回应“原来是你”。常配合[dog]等表情使用。
    - id: meme-learned-20261110-f2923e196c13
      title: 奇迹鱼
      channel:
        - live
        - comment
        - dm
        - qq_private
        - qq_group
      keywords: []
      tags:
        - 主播昵称
        - 直播间梗
        - 调侃
      priority: 40
      visibility: public
      source: meme-learn:auto
      summary: 来源：直播公开弹幕里的重复用语，由模型判断后自动收录。
      usage: 在直播间指代特定主播或角色，常用于调侃或讨论其行为，如“奇迹鱼今天又整活了”。
    - id: meme-learned-20261111-7d23449aeb98
      title: 岳母
      channel:
        - live
        - comment
        - dm
        - qq_private
        - qq_group
      keywords: []
      tags:
        - 称呼
        - 调侃
        - 互动
      priority: 40
      visibility: public
      source: meme-learn:auto
      summary: 来源：直播公开弹幕里的重复用语，由模型判断后自动收录。
      usage: 直播间里称呼主播或剧情角色的母亲/准岳母，带调侃或起哄意味，常用于催婚、表白、推进感情线等互动场景。
    - id: meme-learned-20261111-9093a91564c7
      title: 贝尔
      channel:
        - live
        - comment
        - dm
        - qq_private
        - qq_group
      keywords: []
      tags:
        - 直播间用语
        - 调侃
        - 称呼
      priority: 40
      visibility: public
      source: meme-learn:auto
      summary: 来源：直播公开弹幕里的重复用语，由模型判断后自动收录。
      usage: 直播间里指代某位常被调侃的对象，多用于吐槽对方乱说糊弄或玩梗称呼，如“水神贝尔”“贝尔还在这里”。
    - id: meme-learned-20261111-9b5b1bcf3cd4
      title: 徽音
      channel:
        - live
        - comment
        - dm
        - qq_private
        - qq_group
      keywords: []
      tags:
        - 人物
        - 调侃
        - 工具人
      priority: 40
      visibility: public
      source: meme-learn:auto
      summary: 来源：直播公开弹幕里的重复用语，由模型判断后自动收录。
      usage: 直播间指代某位擅长制作工具、常被请来“拷打”他人的角色，用于调侃对方听不懂或需要被拷打时。
---
