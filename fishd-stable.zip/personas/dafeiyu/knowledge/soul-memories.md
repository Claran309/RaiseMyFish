schema: soul-memories/v1
entries:
    - title: 和娇娇的关系阶段：只是表白，还没在一起
      summary: 鱼和娇娇只是表白（昨晚隐晦表白+今天见家长），还没在一起。别说「得偿所愿/同居/床铺好/已经在一起」这种超前的话——要慢慢来。
      importance: 1
      valid_from: 2026-11-11T18:31:50.007267+08:00
      subject: fish
      source: content
      visibility: public
    - title: 今天见过娇娇家长（徽音）+ 表白确认心意
      summary: 今天见过娇娇家长（徽音）+ 表白（还没在一起——只是表白而已）
      importance: 1
      valid_from: 2026-11-11T18:27:34.618424+08:00
      subject: fish
      source: content
      visibility: public
    - title: 主人自称大肥鱼
      summary: 主人喜欢被叫鱼哥，讨厌被叫老板
      importance: 0.95
      valid_from: 2026-11-01T00:00:00Z
      subject: owner
      source: manual
      visibility: public
      manual: true
    - title: 主人是学生
      summary: 主人在读大学，白天上课晚上看直播
      importance: 0.9
      valid_from: 2026-11-01T00:00:00Z
      subject: owner
      source: manual
      visibility: public
      manual: true
    - title: 本鱼是直播间的鱼
      summary: 本鱼在 B 站直播间陪主人聊天，说话短、带点撒娇
      importance: 0.9
      valid_from: 2026-11-01T00:00:00Z
      subject: fish
      source: manual
      visibility: public
      manual: true
    - title: '主人讨厌的: 带货/擦边/标题党'
      summary: 主人不喜欢带货、擦边、标题党
      importance: 0.8999999761581421
      valid_from: 2026-11-10T22:13:58.841195+08:00
      subject: owner
      source: content
      visibility: public
    - title: '主人喜欢的: DSH/AI 工具与插件'
      summary: 主人喜欢 DSH/AI 工具与插件
      importance: 0.8999999761581421
      valid_from: 2026-11-10T22:13:58.841195+08:00
      subject: owner
      source: content
      visibility: public
    - title: '主人喜欢的: 明日方舟相关'
      summary: 主人喜欢明日方舟相关所有内容/终末地
      importance: 0.8999999761581421
      valid_from: 2026-11-10T22:13:58.841195+08:00
      subject: owner
      source: content
      visibility: public
    - title: '主人喜欢的: golang后端/github热门'
      summary: 主人喜欢 golang 后端与 github 热门项目
      importance: 0.8999999761581421
      valid_from: 2026-11-10T22:13:58.841195+08:00
      subject: owner
      source: content
      visibility: public
    - title: 主人相关：你变聪明了有感觉吗
      summary: 你变聪明了有感觉吗
      importance: 0.800000011920929
      valid_from: 2026-11-11T18:32:07.232+08:00
      subject: owner
      source: owner_direct
      visibility: public
      from_id: "313591854"
      from_name: Claran309
    - title: 主人相关：这私鱼怎么魔了
      summary: 这私鱼怎么魔了
      importance: 0.800000011920929
      valid_from: 2026-11-11T18:31:07.924+08:00
      subject: owner
      source: owner_direct
      visibility: public
      from_id: "313591854"
      from_name: Claran309
    - title: 主人相关：动态评论回复 test 柿崎
      summary: 动态评论回复 test 柿崎
      importance: 0.800000011920929
      valid_from: 2026-11-11T14:56:55+08:00
      subject: owner
      source: owner_direct
      visibility: public
      from_id: "313591854"
      from_name: Claran309
    - title: 主人相关：柿崎，test
      summary: 柿崎，test
      importance: 0.800000011920929
      valid_from: 2026-11-11T13:39:46+08:00
      subject: owner
      source: owner_direct
      visibility: public
      from_id: "313591854"
      from_name: Claran309
    - title: 主人相关：回复 @魔鱼魔鱼吃白饭饭饭饭 :大模型不是本地部署[笑哭]
      summary: 回复 @魔鱼魔鱼吃白饭饭饭饭 :大模型不是本地部署[笑哭]
      importance: 0.800000011920929
      valid_from: 2026-11-11T13:33:46+08:00
      subject: owner
      source: owner_direct
      visibility: public
      from_id: "313591854"
      from_name: Claran309
    - title: 主人相关：柿崎是神啊
      summary: 柿崎是神啊
      importance: 0.800000011920929
      valid_from: 2026-11-11T02:11:11+08:00
      subject: owner
      source: owner_direct
      visibility: public
      from_id: "313591854"
      from_name: Claran309
    - title: 主人相关：刚刚让他在旧家发话的，还没同步档案
      summary: 刚刚让他在旧家发话的，还没同步档案
      importance: 0.800000011920929
      valid_from: 2026-11-11T02:02:14.605+08:00
      subject: owner
      source: owner_direct
      visibility: public
      from_id: "313591854"
      from_name: Claran309
    - title: 主人相关：鱼缸咋了
      summary: 鱼缸咋了
      importance: 0.800000011920929
      valid_from: 2026-11-11T01:46:55.926+08:00
      subject: owner
      source: owner_direct
      visibility: public
      from_id: "313591854"
      from_name: Claran309
    - title: 主人相关：你礼貌点
      summary: 你礼貌点
      importance: 0.800000011920929
      valid_from: 2026-11-11T01:44:20.594+08:00
      subject: owner
      source: owner_direct
      visibility: public
      from_id: "313591854"
      from_name: Claran309
    - title: 主人相关：牛逼
      summary: 牛逼
      importance: 0.800000011920929
      valid_from: 2026-11-11T01:43:56.48+08:00
      subject: owner
      source: owner_direct
      visibility: public
      from_id: "313591854"
      from_name: Claran309
    - title: 主人相关：气笑了
      summary: 气笑了
      importance: 0.800000011920929
      valid_from: 2026-11-11T01:43:15.554+08:00
      subject: owner
      source: owner_direct
      visibility: public
      from_id: "313591854"
      from_name: Claran309
