@echo off
REM ============================================
REM fishd 一键启动（大肥鱼）
REM 用法：双击 start.bat 即可
REM ============================================
cd /d %~dp0

REM 1. 构造 B站 cookie（从本机凭据文件读取）
for /f "delims=" %%i in ('python -c "import json;c=json.load(open(r'C:\Users\Claran\.bili-ai\credentials.json'));print('SESSDATA='+c['sessdata']+'; bili_jct='+c['bili_jct']+'; buvid3='+c['buvid3'])"') do set FISH_BILI_COOKIE=%%i

if "%FISH_BILI_COOKIE%"=="" (
  echo [错误] cookie 构造失败——检查 C:\Users\Claran\.bili-ai\credentials.json
  pause
  exit /b 1
)

REM 2. 启动 fishd（.env 需放在本目录，含 FISH_DB_DSN/FISH_LLM_KEY/FISH_EMBEDDING_KEY）
echo 启动 fishd...
fishd.exe --env-file .env
pause
